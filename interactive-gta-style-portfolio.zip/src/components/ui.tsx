import type { ReactNode } from "react";
import { sound } from "@/lib/audio";
import { cn } from "@/utils/cn";

/* ───────────────────────── surfaces ───────────────────────── */

export const Panel = ({
  children,
  className,
  accent = false,
}: {
  children: ReactNode;
  className?: string;
  accent?: boolean;
}) => (
  <div className={cn("panel clip-panel", accent && "panel-accent", className)}>{children}</div>
);

export const Tag = ({
  children,
  className,
  tone = "mute",
}: {
  children: ReactNode;
  className?: string;
  tone?: "mute" | "accent" | "warn" | "dark";
}) => (
  <span
    className={cn(
      "clip-tag inline-flex items-center gap-1.5 px-2 py-[3px] font-mono text-[9.5px] tracking-[0.2em] uppercase",
      tone === "mute" && "border border-white/12 bg-white/[0.04] text-bone-300/80",
      tone === "accent" && "border bg-[rgba(var(--accent-rgb),0.14)] txt-accent",
      tone === "warn" && "border border-amber-300/30 bg-amber-300/10 text-amber-200",
      tone === "dark" && "bg-black/70 text-bone-300 border border-white/10",
      className,
    )}
    style={tone === "accent" ? { borderColor: "rgba(var(--accent-rgb),0.45)" } : undefined}
  >
    {children}
  </span>
);

/* ───────────────────────── buttons ───────────────────────── */

type BtnBase = {
  children: ReactNode;
  className?: string;
  disabled?: boolean;
  hint?: string;
};

const shell =
  "group clip-btn relative inline-flex items-center gap-2.5 px-4 py-2.5 font-cond text-[12px] font-semibold tracking-[0.22em] uppercase transition-all duration-150 select-none";

export const Btn = ({
  children,
  onClick,
  variant = "ghost",
  className,
  disabled,
  hint,
}: BtnBase & { onClick?: () => void; variant?: "primary" | "ghost" | "danger" }) => (
  <button
    type="button"
    data-cursor={disabled ? "deny" : "link"}
    aria-disabled={disabled}
    title={hint}
    onMouseEnter={() => !disabled && sound.play("hover")}
    onClick={() => {
      if (disabled) {
        sound.play("deny");
        return;
      }
      sound.play("select");
      onClick?.();
    }}
    className={cn(
      shell,
      variant === "primary" &&
        "bg-accent text-ink-950 hover:brightness-110 shadow-[0_0_24px_-6px_rgba(var(--accent-rgb),0.7)]",
      variant === "ghost" && "border border-white/14 bg-white/[0.035] text-bone-100 hover:border-[var(--accent)] hover:bg-[rgba(var(--accent-rgb),0.12)]",
      variant === "danger" && "border border-red-400/30 bg-red-500/10 text-red-200 hover:bg-red-500/20",
      disabled && "opacity-40 hover:!bg-white/[0.03] hover:!border-white/14",
      className,
    )}
  >
    <span className="relative z-10 flex items-center gap-2.5">{children}</span>
    <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/25 to-transparent transition-transform duration-500 group-hover:translate-x-full" />
  </button>
);

export const LinkBtn = ({
  children,
  href,
  variant = "ghost",
  className,
  disabled,
  hint,
}: BtnBase & { href?: string | null; variant?: "primary" | "ghost" }) =>
  href && !disabled ? (
    <a
      href={href}
      target={href.startsWith("http") ? "_blank" : undefined}
      rel={href.startsWith("http") ? "noreferrer noopener" : undefined}
      data-cursor="link"
      onMouseEnter={() => sound.play("hover")}
      onClick={() => sound.play("select")}
      className={cn(
        shell,
        variant === "primary" && "bg-accent text-ink-950 hover:brightness-110 shadow-[0_0_24px_-6px_rgba(var(--accent-rgb),0.7)]",
        variant === "ghost" && "border border-white/14 bg-white/[0.035] text-bone-100 hover:border-[var(--accent)] hover:bg-[rgba(var(--accent-rgb),0.12)]",
        className,
      )}
    >
      <span className="relative z-10 flex items-center gap-2.5">{children}</span>
      <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/25 to-transparent transition-transform duration-500 group-hover:translate-x-full" />
    </a>
  ) : (
    <span
      data-cursor="deny"
      title={hint ?? "LINK PENDING — add it in src/config/portfolio.ts"}
      className={cn(shell, "cursor-not-allowed border border-white/10 bg-white/[0.02] text-bone-500 opacity-50", className)}
    >
      {children}
    </span>
  );

/* ───────────────────────── data bits ───────────────────────── */

export const Row = ({ k, v, mono = true }: { k: string; v: ReactNode; mono?: boolean }) => (
  <div className="flex items-baseline justify-between gap-4 border-b border-white/[0.07] py-2 last:border-0">
    <span className="label shrink-0">{k}</span>
    <span className={cn("text-right text-[12.5px] text-bone-100", mono ? "font-mono tracking-tight" : "font-cond tracking-wide")}>
      {v}
    </span>
  </div>
);

export const Meter = ({ value, blocks = 10, className }: { value: number; blocks?: number; className?: string }) => {
  const filled = Math.round((value / 100) * blocks);
  return (
    <div className={cn("flex gap-[3px]", className)} aria-hidden="true">
      {Array.from({ length: blocks }).map((_, i) => (
        <span
          key={i}
          className="h-[9px] flex-1 transition-colors duration-300"
          style={{
            background: i < filled ? "var(--accent)" : "rgba(255,255,255,0.10)",
            boxShadow: i < filled ? "0 0 8px -2px rgba(var(--accent-rgb),0.8)" : "none",
          }}
        />
      ))}
    </div>
  );
};

export const Bar = ({ value, className }: { value: number; className?: string }) => (
  <div className={cn("relative h-[5px] w-full overflow-hidden bg-white/[0.08]", className)}>
    <div
      className="absolute inset-y-0 left-0 bg-[var(--accent)] transition-[width] duration-700 ease-out"
      style={{ width: `${Math.max(0, Math.min(100, value))}%`, boxShadow: "0 0 10px rgba(var(--accent-rgb),0.7)" }}
    />
  </div>
);

export const KeyValue = ({ label: l, value }: { label: string; value: ReactNode }) => (
  <div className="border-l-2 pl-3" style={{ borderColor: "var(--accent)" }}>
    <div className="label">{l}</div>
    <div className="font-cond text-[13px] tracking-[0.08em] text-bone-100 uppercase">{value}</div>
  </div>
);

/* ───────────────────────── layout ───────────────────────── */

export const ScreenHead = ({
  num,
  title,
  sub,
  right,
}: {
  num: string;
  title: string;
  sub?: string;
  right?: ReactNode;
}) => (
  <header className="flex flex-wrap items-end justify-between gap-3 border-b border-white/10 pb-3">
    <div className="flex items-end gap-3">
      <span
        className="font-display text-[38px] leading-[0.8] sm:text-[52px]"
        style={{ color: "var(--accent)", textShadow: "0 0 28px rgba(var(--accent-rgb),0.45)" }}
      >
        {num}
      </span>
      <div>
        <h2 className="font-display text-[26px] leading-[0.95] tracking-[0.02em] text-bone-100 uppercase sm:text-[38px]">
          {title}
        </h2>
        {sub && <p className="label mt-1">{sub}</p>}
      </div>
    </div>
    {right}
  </header>
);

export const Split = ({ list, detail }: { list: ReactNode; detail: ReactNode }) => (
  <div className="scroll-y grid min-h-0 flex-1 grid-cols-1 gap-3 lg:grid-cols-[minmax(270px,352px)_1fr] lg:overflow-hidden">
    <div className="scroll-y flex min-h-0 flex-col gap-1 lg:max-h-full">{list}</div>
    <div className="scroll-y min-h-0 lg:max-h-full">{detail}</div>
  </div>
);

export const ListRow = ({
  active,
  index,
  title,
  meta,
  onSelect,
  right,
}: {
  active: boolean;
  index: string;
  title: string;
  meta?: string;
  right?: ReactNode;
  onSelect: () => void;
}) => (
  <button
    type="button"
    data-cursor="link"
    onMouseEnter={() => sound.play("hover")}
    onClick={() => {
      sound.play("select");
      onSelect();
    }}
    aria-current={active}
    data-item=""
    className={cn(
      "hover-lift group relative flex w-full items-center gap-3 border-l-2 px-3 py-2.5 text-left transition-colors",
      active ? "bg-[rgba(var(--accent-rgb),0.14)]" : "border-transparent bg-white/[0.02] hover:bg-white/[0.055]",
    )}
    style={active ? { borderColor: "var(--accent)" } : undefined}
  >
    <span className={cn("font-mono text-[10px]", active ? "txt-accent" : "text-bone-500")}>{index}</span>
    <span className="min-w-0 flex-1">
      <span
        className={cn(
          "block truncate font-cond text-[14px] tracking-[0.1em] uppercase",
          active ? "text-bone-100" : "text-bone-300 group-hover:text-bone-100",
        )}
      >
        {title}
      </span>
      {meta && <span className="block truncate font-mono text-[9.5px] tracking-[0.14em] text-bone-500 uppercase">{meta}</span>}
    </span>
    {right}
  </button>
);

export const Chip = ({ children }: { children: ReactNode }) => (
  <span className="clip-tag border border-white/12 bg-black/40 px-2 py-[3px] font-mono text-[9.5px] tracking-[0.16em] text-bone-300 uppercase">
    {children}
  </span>
);

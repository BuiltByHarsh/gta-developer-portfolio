import { useEffect, useRef, useState } from "react";
import { gsap } from "gsap";
import { bootMessages, player, screens, ticker } from "@/config/portfolio";
import { useReducedMotion } from "@/lib/system";

export default function LoadingScreen({
  onDone,
  saveFound,
}: {
  onDone: () => void;
  saveFound: boolean;
}) {
  const reduced = useReducedMotion();
  const [pct, setPct] = useState(0);
  const [msgIdx, setMsgIdx] = useState(0);
  const [skippable, setSkippable] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);
  const done = useRef(false);

  const finish = () => {
    if (done.current) return;
    done.current = true;
    const el = wrapRef.current;
    if (!el || reduced) {
      onDone();
      return;
    }
    const tl = gsap.timeline({ onComplete: onDone });
    tl.to(".boot-line", { opacity: 0, y: -8, duration: 0.25, stagger: 0.03, ease: "power2.in" })
      .to(".boot-plate", { scale: 1.12, opacity: 0, duration: 0.5, ease: "power2.inOut" }, 0)
      .to(el, { opacity: 0, duration: 0.35 }, 0.28);
  };

  useEffect(() => {
    const proxy = { p: 0 };
    const dur = reduced ? 0.4 : 4.4;
    const tween = gsap.to(proxy, {
      p: 100,
      duration: dur,
      ease: reduced ? "none" : "power1.inOut",
      onUpdate: () => setPct(Math.round(proxy.p)),
      onComplete: () => {
        setMsgIdx(bootMessages.length - 1);
        window.setTimeout(finish, reduced ? 120 : 620);
      },
    });
    const skipTimer = window.setTimeout(() => setSkippable(true), 1500);
    const msgTimer = window.setInterval(
      () => setMsgIdx((i) => (i + 1) % (bootMessages.length - 1)),
      780,
    );
    gsap.from(".boot-line", { opacity: 0, y: 14, duration: 0.5, stagger: 0.07, ease: "power2.out" });
    return () => {
      tween.kill();
      window.clearTimeout(skipTimer);
      window.clearInterval(msgTimer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reduced]);

  const pctStr = String(pct).padStart(2, "0");

  return (
    <div ref={wrapRef} className="fixed inset-0 z-[150] overflow-hidden bg-ink-950">
      <div
        className="boot-plate absolute inset-0 bg-cover opacity-[0.34]"
        style={{
          backgroundImage: `linear-gradient(180deg, rgba(5,7,10,0.55), rgba(5,7,10,0.96)), url(${screens[0].image})`,
          backgroundPosition: "60% 40%",
        }}
      />
      <div className="scanlines pointer-events-none absolute inset-0" />
      <div className="noise pointer-events-none absolute inset-0" />
      <div className="vignette pointer-events-none absolute inset-0" />

      <div className="relative flex h-full flex-col justify-between p-6 sm:p-10">
        <div className="flex items-start justify-between gap-4">
          <div className="boot-line">
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 anim-blink" style={{ background: "var(--accent)" }} />
              <span className="label txt-accent">PORTFOLIO SYSTEM</span>
            </div>
            <div className="label mt-1">PLAYER // {player.handle} · {player.playerId}</div>
          </div>
          <div className="boot-line text-right">
            <div className="label">{player.build}</div>
            <div className="label mt-1">REGION // {player.region}</div>
          </div>
        </div>

        <div className="boot-line max-w-[820px]">
          <p className="label mb-3">SYSTEM BOOT SEQUENCE</p>
          <h1 className="font-display text-[clamp(46px,11vw,132px)] leading-[0.82] tracking-[0.01em] text-bone-100 uppercase">
            {player.first}
            <br />
            <span className="txt-accent glow-text anim-flicker">{player.last}</span>
          </h1>
          <p className="mt-4 max-w-[46ch] font-cond text-[15px] tracking-[0.24em] text-bone-300 uppercase">
            {player.tagline}
          </p>
        </div>

        <div className="boot-line">
          <div className="mb-2 flex flex-wrap items-end justify-between gap-3">
            <div className="flex items-baseline gap-3">
              <span className="label">LOADING WORLD...</span>
              <span className="font-mono text-[11px] tracking-[0.16em] text-bone-300">
                {bootMessages[msgIdx]}
              </span>
              {saveFound && (
                <span className="clip-tag border border-emerald-300/40 bg-emerald-400/10 px-2 py-[3px] font-mono text-[9.5px] tracking-[0.18em] text-emerald-200 uppercase">
                  SAVE DATA FOUND
                </span>
              )}
            </div>
            <div className="font-display text-[clamp(30px,7vw,64px)] leading-none text-bone-100 tabular-nums">
              {pctStr}
              <span className="txt-accent">%</span>
            </div>
          </div>

          <div className="relative h-[6px] w-full bg-white/[0.08]">
            <div
              className="absolute inset-y-0 left-0 bg-[var(--accent)]"
              style={{ width: `${pct}%`, boxShadow: "0 0 20px rgba(var(--accent-rgb),0.8)" }}
            />
            <div className="absolute inset-0 flex">
              {Array.from({ length: 40 }).map((_, i) => (
                <span key={i} className="h-full flex-1 border-r border-ink-950/70 last:border-0" />
              ))}
            </div>
          </div>

          <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
              {bootMessages.map((m, i) => (
                <span
                  key={m}
                  className="font-mono text-[9.5px] tracking-[0.18em] uppercase transition-colors"
                  style={{ color: i <= msgIdx ? "var(--accent)" : "rgba(185,195,203,0.35)" }}
                >
                  {i <= msgIdx ? "✓ " : "· "}
                  {m}
                </span>
              ))}
            </div>
            <button
              type="button"
              data-cursor="link"
              onClick={finish}
              className={`clip-btn border border-white/15 bg-black/50 px-4 py-2 font-cond text-[11px] tracking-[0.24em] uppercase transition-all ${
                skippable ? "text-bone-100 hover:border-[var(--accent)] hover:txt-accent" : "text-bone-500/40"
              }`}
              disabled={!skippable}
            >
              SKIP ▸
            </button>
          </div>

          <div className="mt-5 hidden overflow-hidden border-t border-white/10 pt-2 sm:block">
            <div className="anim-ticker flex w-max gap-8">
              {[...ticker, ...ticker].map((t, i) => (
                <span key={i} className="font-mono text-[9.5px] tracking-[0.2em] text-bone-500 uppercase">
                  {t}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

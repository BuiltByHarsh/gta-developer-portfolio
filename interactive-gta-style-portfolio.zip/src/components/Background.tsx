import { useEffect, useRef, useState } from "react";
import { gsap } from "gsap";
import type { ScreenDef } from "@/config/portfolio";
import { prefersReducedMotion } from "@/lib/system";

/**
 * Cinematic plate stack. Every screen owns one artwork + one accent.
 * Dark anchors (left ramp, bottom ramp, vignette) keep the UI readable
 * even on the bright plates. Falls back to the configured gradient if the
 * artwork ever fails to decode — never a broken image icon.
 */
export default function Background({ screen }: { screen: ScreenDef }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const parallaxRef = useRef<HTMLDivElement>(null);
  const [imgFailed, setImgFailed] = useState(false);

  useEffect(() => setImgFailed(false), [screen.id]);

  // Ambient camera drift — desktop only, never under reduced motion.
  useEffect(() => {
    const el = parallaxRef.current;
    if (!el || prefersReducedMotion() || window.matchMedia("(pointer: coarse)").matches) return;
    const qx = gsap.quickTo(el, "x", { duration: 1.2, ease: "power3.out" });
    const qy = gsap.quickTo(el, "y", { duration: 1.2, ease: "power3.out" });
    const onMove = (e: MouseEvent) => {
      qx((e.clientX / window.innerWidth - 0.5) * -26);
      qy((e.clientY / window.innerHeight - 0.5) * -16);
    };
    window.addEventListener("mousemove", onMove, { passive: true });
    return () => window.removeEventListener("mousemove", onMove);
  }, []);

  // Pause hidden video, resume when the tab comes back.
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    const onVis = () => {
      if (document.hidden) v.pause();
      else void v.play().catch(() => undefined);
    };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, [screen.video]);

  return (
    <div id="bg-root" className="pointer-events-none fixed inset-0 -z-10 overflow-hidden bg-ink-950">
      <div className="absolute inset-0" style={{ background: screen.fallback }} />

      <div id="bg-active" className="absolute inset-0 will-change-transform">
        <div ref={parallaxRef} className="absolute inset-0 scale-[1.07] will-change-transform">
        {screen.video ? (
          <video
            ref={videoRef}
            className="h-full w-full object-cover opacity-[0.55]"
            src={screen.video}
            autoPlay
            muted
            loop
            playsInline
            preload="metadata"
            aria-hidden="true"
          />
        ) : (
          <img
            key={screen.id}
            src={screen.image}
            alt=""
            aria-hidden="true"
            decoding="async"
            fetchPriority="high"
            onError={() => setImgFailed(true)}
            className="h-full w-full object-cover"
            style={{
              objectPosition: screen.position,
              opacity: imgFailed ? 0 : 1,
              transition: "opacity .5s ease",
            }}
          />
        )}
        </div>
      </div>

      {/* accent atmosphere */}
      <div
        className="absolute inset-0 mix-blend-screen"
        style={{
          background:
            "radial-gradient(75% 60% at 72% 28%, rgba(var(--accent-rgb),0.20), transparent 62%), radial-gradient(60% 50% at 18% 82%, rgba(var(--accent-rgb),0.10), transparent 60%)",
        }}
      />
      {/* dark anchors */}
      <div className="anchor-left absolute inset-0" />
      <div
        className="absolute inset-0"
        style={{ background: "linear-gradient(to top, rgba(4,6,9,0.97) 0%, rgba(4,6,9,0.55) 22%, transparent 52%)" }}
      />
      <div
        className="absolute inset-x-0 top-0 h-40"
        style={{ background: "linear-gradient(to bottom, rgba(4,6,9,0.92), transparent)" }}
      />
      <div className="vignette absolute inset-0" />
      <div className="scanlines absolute inset-0" />
      <div className="noise absolute inset-0" />
    </div>
  );
}

import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { Volume2, VolumeX, Star, Radio } from "lucide-react";
import { player, type ScreenDef } from "@/config/portfolio";
import { useClock, formatClock, formatDate } from "@/lib/system";
import { sound } from "@/lib/audio";

export default function HUD({
  screen,
  stars,
  xp,
  completion,
  soundOn,
  onToggleSound,
}: {
  screen: ScreenDef;
  stars: number;
  xp: number;
  completion: number;
  soundOn: boolean;
  onToggleSound: () => void;
}) {
  const now = useClock();
  const valueRef = useRef<HTMLSpanElement>(null);
  const numRef = useRef({ v: 0 });

  useEffect(() => {
    gsap.to(numRef.current, {
      v: xp,
      duration: 1.1,
      ease: "power2.out",
      onUpdate: () => {
        if (valueRef.current) valueRef.current.textContent = Math.round(numRef.current.v).toLocaleString("en-US");
      },
    });
  }, [xp]);

  return (
    <header className="relative z-30 flex items-start justify-between gap-3 px-4 pt-4 sm:px-7 sm:pt-5">
      {/* ── identity ── */}
      <div className="min-w-0">
        <div className="flex items-center gap-2">
          <span className="h-1.5 w-1.5 anim-blink bg-[var(--accent)]" />
          <span className="label txt-accent">Player Profile</span>
          <span className="label hidden sm:inline">// {player.playerId}</span>
        </div>
        <h1 className="mt-0.5 truncate font-display text-[clamp(19px,3.1vw,32px)] leading-[0.9] tracking-[0.01em] text-bone-100 uppercase">
          {player.name}
        </h1>
        <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1">
          <span className="label hidden md:inline">{player.location}</span>
          <span className="label txt-accent">LVL {player.level}</span>
          <span className="label hidden lg:inline">{player.class}</span>
          <span className="label hidden xl:inline">
            {screen.sector} · {screen.coords}
          </span>
        </div>

        {/* reputation */}
        <div className="mt-2 flex items-center gap-2">
          <span className="label">Reputation</span>
          <span className="flex gap-[3px]" role="img" aria-label={`Reputation ${stars} of 5 stars`}>
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                size={13}
                strokeWidth={1.5}
                className={i < stars ? "text-[var(--accent)] drop-shadow-[0_0_6px_rgba(var(--accent-rgb),0.9)]" : "text-white/15"}
                fill={i < stars ? "var(--accent)" : "none"}
              />
            ))}
          </span>
          <span className="label hidden sm:inline">{completion}%</span>
        </div>
      </div>

      {/* ── clock + value ── */}
      <div className="flex shrink-0 flex-col items-end gap-1">
        <div className="flex items-center gap-2">
          <button
            type="button"
            data-cursor="link"
            onClick={() => {
              onToggleSound();
            }}
            onMouseEnter={() => sound.play("hover")}
            aria-pressed={soundOn}
            aria-label={soundOn ? "Mute interface sound" : "Enable interface sound"}
            className="clip-tag flex h-7 w-7 items-center justify-center border border-white/12 bg-black/50 text-bone-300 transition-colors hover:border-[var(--accent)] hover:txt-accent"
          >
            {soundOn ? <Volume2 size={13} /> : <VolumeX size={13} />}
          </button>
          <span className="clip-tag hidden items-center gap-1.5 border border-white/12 bg-black/50 px-2 py-1 font-mono text-[9px] tracking-[0.18em] text-bone-300 uppercase sm:flex">
            <Radio size={10} className="txt-accent anim-blink" />
            {player.status}
          </span>
        </div>

        <div className="text-right">
          <div className="font-display text-[clamp(22px,3.6vw,34px)] leading-[0.85] text-bone-100 tabular-nums">
            {formatClock(now)}
          </div>
          <div className="label mt-1 tabular-nums">{formatDate(now)}</div>
        </div>

        <div className="mt-1 text-right">
          <div className="label">Portfolio Value · XP</div>
          <div className="font-cond text-[clamp(16px,2.4vw,22px)] font-semibold tracking-[0.1em] tabular-nums" style={{ color: "var(--accent)" }}>
            $ <span ref={valueRef}>0</span>
          </div>
        </div>
      </div>
    </header>
  );
}

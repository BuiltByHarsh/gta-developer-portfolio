import { useEffect, useRef } from "react";
import { screens } from "@/config/portfolio";
import { sound } from "@/lib/audio";
import { cn } from "@/utils/cn";

export default function TabNav({
  active,
  visited,
  onSelect,
}: {
  active: number;
  visited: Set<string>;
  onSelect: (i: number) => void;
}) {
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = listRef.current?.querySelector<HTMLElement>(`[data-tab="${active}"]`);
    el?.scrollIntoView({ behavior: "smooth", inline: "center", block: "nearest" });
  }, [active]);

  return (
    <nav
      aria-label="Portfolio sectors"
      className="relative z-30 border-y border-white/10 bg-black/55 backdrop-blur-[3px]"
    >
      <div ref={listRef} className="scroll-x flex overflow-x-auto">
        {screens.map((s, i) => {
          const isActive = i === active;
          const seen = visited.has(s.id);
          return (
            <button
              key={s.id}
              type="button"
              data-tab={i}
              data-cursor="nav"
              aria-current={isActive ? "page" : undefined}
              onMouseEnter={() => sound.play("hover")}
              onClick={() => {
                sound.play("select");
                onSelect(i);
              }}
              className={cn(
                "group relative flex shrink-0 items-center gap-2 border-r border-white/[0.07] px-3 py-2 transition-colors duration-200 sm:px-4 sm:py-2.5",
                isActive ? "bg-[rgba(var(--accent-rgb),0.16)]" : "hover:bg-white/[0.06]",
              )}
            >
              <span
                className="absolute inset-x-0 top-0 h-[2px] origin-left transition-transform duration-300"
                style={{
                  background: "var(--accent)",
                  transform: isActive ? "scaleX(1)" : "scaleX(0)",
                  boxShadow: isActive ? "0 0 12px rgba(var(--accent-rgb),0.9)" : "none",
                }}
              />
              <span
                className={cn(
                  "font-mono text-[9px] tracking-[0.1em]",
                  isActive ? "txt-accent" : "text-bone-500/70",
                )}
              >
                {s.num}
              </span>
              <span
                className={cn(
                  "font-cond text-[11.5px] tracking-[0.2em] whitespace-nowrap uppercase transition-colors sm:text-[12.5px]",
                  isActive ? "text-bone-100" : "text-bone-500 group-hover:text-bone-300",
                )}
              >
                {s.label}
              </span>
              {seen && !isActive && (
                <span className="h-1 w-1 rounded-full bg-emerald-400/80" title="Sector visited" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}

import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { useIsTouch, useReducedMotion } from "@/lib/system";

/** Desktop-only cursor: a bracket reticle that reacts to interactive elements. */
export default function CustomCursor() {
  const isTouch = useIsTouch();
  const reduced = useReducedMotion();
  const ringRef = useRef<HTMLDivElement>(null);
  const dotRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const root = document.documentElement;
    if (isTouch) {
      root.classList.remove("cursor-hidden");
      return;
    }
    root.classList.add("cursor-hidden");
    return () => root.classList.remove("cursor-hidden");
  }, [isTouch]);

  useEffect(() => {
    if (isTouch) return;
    const ring = ringRef.current;
    const dot = dotRef.current;
    if (!ring || !dot) return;

    const dur = reduced ? 0 : 0.22;
    const rx = gsap.quickTo(ring, "x", { duration: dur, ease: "power3.out" });
    const ry = gsap.quickTo(ring, "y", { duration: dur, ease: "power3.out" });
    const dx = gsap.quickTo(dot, "x", { duration: 0.05, ease: "power2.out" });
    const dy = gsap.quickTo(dot, "y", { duration: 0.05, ease: "power2.out" });

    let raf = 0;
    const onMove = (e: MouseEvent) => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        rx(e.clientX);
        ry(e.clientY);
        dx(e.clientX);
        dy(e.clientY);
      });
      const target = (e.target as HTMLElement)?.closest("[data-cursor]") as HTMLElement | null;
      const mode = target?.dataset.cursor ?? "default";
      ring.dataset.mode = mode;
      if (labelRef.current) labelRef.current.textContent = mode === "deny" ? "LOCKED" : "";
    };
    const onLeave = () => {
      gsap.to([ring, dot], { opacity: 0, duration: 0.2 });
    };
    const onEnter = () => gsap.to([ring, dot], { opacity: 1, duration: 0.2 });

    window.addEventListener("mousemove", onMove, { passive: true });
    document.addEventListener("mouseleave", onLeave);
    document.addEventListener("mouseenter", onEnter);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("mousemove", onMove);
      document.removeEventListener("mouseleave", onLeave);
      document.removeEventListener("mouseenter", onEnter);
    };
  }, [isTouch, reduced]);

  if (isTouch) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-[200] hidden [@media(pointer:fine)]:block">
      <div
        ref={ringRef}
        data-mode="default"
        className="absolute top-0 left-0 -mt-4 -ml-4 h-8 w-8 transition-[transform,border-color,opacity] duration-200
                   border border-white/60 mix-blend-difference
                   data-[mode=link]:scale-[1.5] data-[mode=link]:border-[var(--accent)] data-[mode=link]:mix-blend-normal
                   data-[mode=deny]:scale-[1.3] data-[mode=deny]:border-red-400 data-[mode=deny]:mix-blend-normal
                   data-[mode=nav]:scale-x-[1.7] data-[mode=nav]:border-white/80"
      >
        <span className="absolute inset-y-[9px] -left-[5px] w-[3px] bg-[var(--accent)] opacity-70" />
        <span className="absolute inset-y-[9px] -right-[5px] w-[3px] bg-[var(--accent)] opacity-70" />
      </div>
      <div ref={dotRef} className="absolute top-0 left-0 -mt-[2px] -ml-[2px] h-1 w-1 bg-white mix-blend-difference" />
      <span
        ref={labelRef}
        className="absolute top-0 left-0 mt-5 ml-5 font-mono text-[9px] tracking-[0.2em] text-red-300 uppercase"
      />
    </div>
  );
}

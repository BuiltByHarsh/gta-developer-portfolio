import { screens, type ScreenDef } from "@/config/portfolio";

const blocks = [
  [6, 8, 16, 12],
  [26, 6, 12, 9],
  [44, 10, 18, 8],
  [68, 6, 20, 12],
  [8, 26, 14, 14],
  [28, 24, 10, 10],
  [46, 26, 20, 14],
  [72, 24, 16, 10],
  [10, 46, 12, 16],
  [30, 44, 18, 12],
  [54, 46, 12, 14],
  [74, 42, 14, 16],
  [8, 68, 18, 14],
  [32, 66, 12, 12],
  [52, 68, 20, 12],
  [76, 66, 12, 16],
  [16, 88, 22, 8],
  [58, 86, 24, 9],
];

const roads = [
  { d: "M0,22 H100", w: 1.6 },
  { d: "M0,62 H100", w: 1.2 },
  { d: "M0,84 H100", w: 0.9 },
  { d: "M24,0 V100", w: 1.4 },
  { d: "M50,0 V100", w: 1.1 },
  { d: "M70,0 V100", w: 0.9 },
];

export default function MiniMap({ screen, visited }: { screen: ScreenDef; visited: Set<string> }) {
  const route = screens.filter((s) => visited.has(s.id));
  const points = route.map((s) => `${s.map.x},${s.map.y}`).join(" ");

  return (
    <div className="pointer-events-none fixed bottom-[38px] left-6 z-30 hidden sm:block">
      <div className="relative w-[156px]">
        <div className="relative overflow-hidden border border-white/15 bg-[#06090c]/92">
          <svg viewBox="0 0 100 100" className="block w-full" role="img" aria-label={`Minimap — ${screen.gameLabel}`}>
            <defs>
              <radialGradient id="sweep" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="rgba(var(--accent-rgb),0.55)" />
                <stop offset="100%" stopColor="rgba(var(--accent-rgb),0)" />
              </radialGradient>
              <clipPath id="mapClip">
                <rect x="0" y="0" width="100" height="100" />
              </clipPath>
            </defs>

            <g clipPath="url(#mapClip)">
              <rect x="0" y="0" width="100" height="100" fill="#06090c" />
              {blocks.map(([x, y, w, h], i) => (
                <rect
                  key={i}
                  x={x}
                  y={y}
                  width={w}
                  height={h}
                  fill="rgba(255,255,255,0.055)"
                  stroke="rgba(255,255,255,0.07)"
                  strokeWidth="0.3"
                />
              ))}
              {roads.map((r, i) => (
                <path key={i} d={r.d} stroke="rgba(255,255,255,0.16)" strokeWidth={r.w} fill="none" />
              ))}

              {/* radar sweep */}
              <g className="anim-sweep" style={{ transformOrigin: "50px 50px" }}>
                <path d="M50,50 L50,2 A48,48 0 0,1 80,13 Z" fill="url(#sweep)" opacity="0.45" />
              </g>

              {/* travelled route */}
              {points && (
                <polyline
                  key={points}
                  points={points}
                  fill="none"
                  stroke="var(--accent)"
                  strokeWidth="0.9"
                  strokeDasharray="2.4 1.8"
                  opacity="0.85"
                />
              )}

              {/* sector blips */}
              {screens.map((s) => {
                const seen = visited.has(s.id);
                const isHere = s.id === screen.id;
                return (
                  <g key={s.id}>
                    <rect
                      x={s.map.x - 1.1}
                      y={s.map.y - 1.1}
                      width="2.2"
                      height="2.2"
                      fill={seen ? "rgba(var(--accent-rgb),0.5)" : "rgba(255,255,255,0.22)"}
                    />
                    {isHere && (
                      <>
                        <circle cx={s.map.x} cy={s.map.y} r="6" fill="none" stroke="var(--accent)" strokeWidth="0.5" opacity="0.5">
                          <animate attributeName="r" values="3;9" dur="2.2s" repeatCount="indefinite" />
                          <animate attributeName="opacity" values="0.6;0" dur="2.2s" repeatCount="indefinite" />
                        </circle>
                      </>
                    )}
                  </g>
                );
              })}

              {/* player marker */}
              <g
                style={{
                  transform: `translate(${screen.map.x}px, ${screen.map.y}px)`,
                  transition: "transform .65s cubic-bezier(.22,.9,.24,1)",
                }}
              >
                <path d="M0,-4.4 L3.4,3.6 L0,1.8 L-3.4,3.6 Z" fill="var(--accent)" stroke="#05070a" strokeWidth="0.4" />
              </g>
            </g>

            <rect x="0.5" y="0.5" width="99" height="99" fill="none" stroke="rgba(var(--accent-rgb),0.35)" strokeWidth="1" />
          </svg>

          {/* corner ticks */}
          <span className="absolute top-0 left-0 h-2 w-2 border-t border-l border-[var(--accent)]" />
          <span className="absolute top-0 right-0 h-2 w-2 border-t border-r border-[var(--accent)]" />
          <span className="absolute bottom-0 left-0 h-2 w-2 border-b border-l border-[var(--accent)]" />
          <span className="absolute right-0 bottom-0 h-2 w-2 border-r border-b border-[var(--accent)]" />
          <div className="scanlines pointer-events-none absolute inset-0" />
        </div>

        <div className="mt-1 flex items-baseline justify-between gap-2">
          <span className="truncate font-cond text-[10.5px] tracking-[0.14em] uppercase sm:text-[12px]">
            <span className="txt-accent">{screen.label}</span>
            <span className="text-bone-500"> — {screen.sector.replace("SECTOR ", "S")}</span>
          </span>
          <span className="hidden font-mono text-[8.5px] tracking-[0.1em] text-bone-500 sm:inline">
            {screen.map.x.toString().padStart(2, "0")}/{screen.map.y.toString().padStart(2, "0")}
          </span>
        </div>
      </div>
    </div>
  );
}

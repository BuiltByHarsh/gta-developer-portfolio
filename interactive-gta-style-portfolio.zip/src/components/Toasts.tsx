import { Award, Lock, Radio, Star, CheckCircle2 } from "lucide-react";
import type { Toast } from "@/hooks/useToasts";

const iconFor = (kind: Toast["kind"]) => {
  switch (kind) {
    case "unlock":
      return <Award size={15} />;
    case "mission":
      return <Star size={15} />;
    case "complete":
      return <CheckCircle2 size={15} />;
    case "save":
      return <Lock size={15} />;
    default:
      return <Radio size={15} />;
  }
};

export default function Toasts({ toasts, onDismiss }: { toasts: Toast[]; onDismiss: (id: number) => void }) {
  return (
    <div
      className="pointer-events-none fixed right-3 bottom-[34px] z-40 flex w-[236px] flex-col items-stretch gap-2 sm:right-6 sm:w-[296px]"
      aria-live="polite"
    >
      {toasts.map((t) => (
        <button
          key={t.id}
          type="button"
          onClick={() => onDismiss(t.id)}
          data-cursor="link"
          className="toast-in clip-panel-sm pointer-events-auto relative flex w-full gap-3 border border-white/12 bg-ink-900/95 py-2.5 pr-3 pl-4 text-left shadow-[0_18px_40px_-24px_rgba(0,0,0,0.9)]"
        >
          <span
            className="absolute inset-y-0 left-0 w-[3px]"
            style={{ background: "var(--accent)", boxShadow: "0 0 14px rgba(var(--accent-rgb),0.85)" }}
          />
          <span className="mt-[1px] txt-accent">{iconFor(t.kind)}</span>
          <span className="min-w-0 flex-1">
            <span className="block font-cond text-[12.5px] leading-tight tracking-[0.16em] text-bone-100 uppercase">
              {t.title}
            </span>
            {t.body && (
              <span className="mt-1 block truncate font-mono text-[9px] tracking-[0.12em] text-bone-500 uppercase">
                {t.body}
              </span>
            )}
          </span>
        </button>
      ))}
    </div>
  );
}

import { useCallback, useEffect, useRef, useState } from "react";

export type ToastKind = "mission" | "unlock" | "info" | "complete" | "save";

export interface Toast {
  id: number;
  title: string;
  body?: string;
  kind: ToastKind;
}

let seq = 0;

export function useToasts() {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const timers = useRef<number[]>([]);

  const dismiss = useCallback((id: number) => {
    setToasts((list) => list.filter((t) => t.id !== id));
  }, []);

  const push = useCallback(
    (title: string, body?: string, kind: ToastKind = "info", ms = 3200) => {
      const id = ++seq;
      setToasts((list) => [...list.slice(-3), { id, title, body, kind }]);
      const timer = window.setTimeout(() => dismiss(id), ms);
      timers.current.push(timer);
      return id;
    },
    [dismiss],
  );

  useEffect(() => () => timers.current.forEach((t) => window.clearTimeout(t)), []);

  return { toasts, push, dismiss };
}

export type ToastApi = ReturnType<typeof useToasts>;

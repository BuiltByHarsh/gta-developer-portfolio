import { useCallback, useEffect, useRef, useState } from "react";
import { achievements, contracts, missions, screens, skillBranches } from "@/config/portfolio";

const KEY = "HS_PORTFOLIO_SAVE_V1";

export interface SaveData {
  v: number;
  visited: string[];
  missions: string[];
  contracts: string[];
  sound: boolean;
  createdAt: number;
}

const blank: SaveData = { v: 1, visited: [], missions: [], contracts: [], sound: false, createdAt: 0 };

const SECTOR_WEIGHT = 8;
const MISSION_WEIGHT = 4;
const CONTRACT_WEIGHT = 3;
const TOTAL_WEIGHT =
  screens.length * SECTOR_WEIGHT + missions.length * MISSION_WEIGHT + contracts.length * CONTRACT_WEIGHT;

function read(): { data: SaveData; found: boolean } {
  if (typeof window === "undefined") return { data: blank, found: false };
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return { data: blank, found: false };
    const parsed = JSON.parse(raw) as SaveData;
    return {
      data: { ...blank, ...parsed, visited: parsed.visited ?? [], missions: parsed.missions ?? [], contracts: parsed.contracts ?? [] },
      found: true,
    };
  } catch {
    return { data: blank, found: false };
  }
}

export function useProgress() {
  const initial = useRef(read());
  const [data, setData] = useState<SaveData>(initial.current.data);
  const [saveFound] = useState(initial.current.found);

  useEffect(() => {
    try {
      window.localStorage.setItem(KEY, JSON.stringify(data));
    } catch {
      /* storage blocked — the interface keeps working without persistence */
    }
  }, [data]);

  const visited = new Set(data.visited);
  const openedMissions = new Set(data.missions);
  const takenContracts = new Set(data.contracts);

  const markVisited = useCallback((id: string) => {
    setData((d) => (d.visited.includes(id) ? d : { ...d, visited: [...d.visited, id], createdAt: d.createdAt || Date.now() }));
  }, []);
  const markMission = useCallback((id: string) => {
    setData((d) => (d.missions.includes(id) ? d : { ...d, missions: [...d.missions, id] }));
  }, []);
  const markContract = useCallback((id: string) => {
    setData((d) => (d.contracts.includes(id) ? d : { ...d, contracts: [...d.contracts, id] }));
  }, []);
  const toggleSound = useCallback((on: boolean) => setData((d) => ({ ...d, sound: on })), []);
  const reset = useCallback(() => setData({ ...blank, createdAt: Date.now() }), []);

  const completion = Math.round(
    (visited.size * SECTOR_WEIGHT + openedMissions.size * MISSION_WEIGHT + takenContracts.size * CONTRACT_WEIGHT) /
      TOTAL_WEIGHT *
      100,
  );

  const xp =
    screens.filter((s) => visited.has(s.id)).reduce((a, s) => a + s.xp, 0) +
    missions.filter((m) => openedMissions.has(m.id)).reduce((a, m) => a + m.xp, 0) +
    achievements.filter((a) => a.unlocked).reduce((a, b) => a + b.xp, 0) +
    takenContracts.size * 500;

  const totalSkills = skillBranches.reduce((a, b) => a + b.skills.length, 0);
  const stars = Math.min(5, Math.max(1, ["home", "about", "skills", "projects", "experience"].filter((s) => visited.has(s)).length));

  return {
    data,
    saveFound,
    visited,
    openedMissions,
    takenContracts,
    markVisited,
    markMission,
    markContract,
    toggleSound,
    reset,
    completion,
    xp,
    stars,
    totals: {
      sectors: screens.length,
      missions: missions.length,
      missionsCompleted: missions.filter((m) => m.status === "COMPLETED").length,
      skills: totalSkills,
      achievements: achievements.length,
      unlocked: achievements.filter((a) => a.unlocked).length,
      contracts: contracts.length,
    },
  };
}

export type ProgressApi = ReturnType<typeof useProgress>;

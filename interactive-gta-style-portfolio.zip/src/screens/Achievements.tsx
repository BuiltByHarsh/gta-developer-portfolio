import { Award, Lock, Trophy } from "lucide-react";
import { Icon } from "@/lib/icons";
import { Bar, Panel, ScreenHead, Tag } from "@/components/ui";
import { achievements, byId } from "@/config/portfolio";
import type { ScreenProps } from "@/screens/types";

export default function Achievements({ progress, toast }: ScreenProps) {
  const unlocked = achievements.filter((a) => a.unlocked);
  const locked = achievements.filter((a) => !a.unlocked);
  const totalXp = unlocked.reduce((a, b) => a + b.xp, 0);
  const pct = Math.round((unlocked.length / achievements.length) * 100);

  return (
    <div className="scroll-y flex min-h-0 flex-1 flex-col gap-4">
      <ScreenHead
        num="06"
        title="Trophy Room"
        sub={`${byId("achievements").sector} · ${unlocked.length}/${achievements.length} UNLOCKED`}
        right={
          <div className="flex items-center gap-2">
            <Tag tone="accent">
              <Trophy size={10} /> {totalXp.toLocaleString("en-US")} XP EARNED
            </Tag>
            <Tag>{locked.length} LOCKED</Tag>
          </div>
        }
      />

      <Panel className="p-4" accent>
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <span className="label">Progression</span>
            <div className="font-display text-[30px] leading-none text-bone-100 tabular-nums sm:text-[38px]">
              {pct}
              <span className="txt-accent">%</span>
              <span className="ml-3 font-cond text-[13px] tracking-[0.18em] text-bone-500 uppercase">
                trophy completion
              </span>
            </div>
          </div>
          <div className="min-w-[180px] flex-1">
            <Bar value={pct} />
            <p className="label mt-2">World completion tracked at {progress.completion}% — save slot 01</p>
          </div>
        </div>
      </Panel>

      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-3">
        {achievements.map((a, i) =>
          a.unlocked ? (
            <button
              key={a.id}
              type="button"
              data-item=""
              data-cursor="link"
              onClick={() => toast("ACHIEVEMENT VIEWED", `${a.name} · +${a.xp} XP`, "unlock", 2200)}
              className="hover-lift group relative overflow-hidden border border-[rgba(var(--accent-rgb),0.35)] bg-[rgba(var(--accent-rgb),0.07)] p-3 text-left"
            >
              <span
                className="absolute inset-y-0 left-0 w-[3px] bg-[var(--accent)]"
                style={{ boxShadow: "0 0 14px rgba(var(--accent-rgb),0.85)" }}
              />
              <div className="flex items-start gap-3 pl-2">
                <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center border border-[rgba(var(--accent-rgb),0.4)] bg-black/40 txt-accent">
                  <Icon name={a.icon} size={17} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex items-center justify-between gap-2">
                    <span className="font-cond text-[13.5px] tracking-[0.14em] text-bone-100 uppercase">{a.name}</span>
                    <span className="font-mono text-[9px] tracking-[0.14em] txt-accent">#{String(i + 1).padStart(3, "0")}</span>
                  </span>
                  <span className="mt-1 block text-[12.5px] leading-snug text-bone-300">{a.desc}</span>
                  <span className="label mt-2 flex items-center gap-2">
                    <Award size={10} /> UNLOCKED {a.date ? `· ${a.date}` : ""} · +{a.xp} XP
                  </span>
                </span>
              </div>
            </button>
          ) : (
            <div
              key={a.id}
              className="relative border border-white/[0.08] bg-black/45 p-3 opacity-70"
              title="Locked achievement"
            >
              <span className="absolute inset-y-0 left-0 w-[3px] bg-white/10" />
              <div className="flex items-start gap-3 pl-2">
                <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center border border-white/10 bg-black/50 text-bone-500">
                  <Lock size={16} />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-cond text-[13.5px] tracking-[0.14em] text-bone-500 uppercase">???</span>
                    <span className="font-mono text-[9px] tracking-[0.14em] text-bone-500">
                      #{String(i + 1).padStart(3, "0")}
                    </span>
                  </div>
                  <p className="mt-1 font-mono text-[10px] tracking-[0.14em] text-bone-500 uppercase">
                    Mission not yet unlocked
                  </p>
                  <p className="label mt-2">Progress: {a.name.replace(/ /g, " · ")}</p>
                </div>
              </div>
            </div>
          ),
        )}
      </div>

      <Panel className="p-4">
        <span className="label">Next Unlock Conditions</span>
        <div className="mt-2 grid gap-2 sm:grid-cols-2">
          {locked.map((a) => (
            <div key={a.id} className="flex items-center justify-between border border-white/[0.07] bg-white/[0.02] px-3 py-2">
              <span className="font-cond text-[12.5px] tracking-[0.12em] text-bone-300 uppercase">{a.name}</span>
              <span className="font-mono text-[9.5px] tracking-[0.14em] text-bone-500">{a.xp} XP</span>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}

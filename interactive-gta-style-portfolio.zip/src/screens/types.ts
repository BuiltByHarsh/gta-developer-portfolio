import type { ScreenId } from "@/config/portfolio";
import type { ProgressApi } from "@/hooks/useProgress";
import type { ToastApi } from "@/hooks/useToasts";

export interface ScreenProps {
  progress: ProgressApi;
  toast: ToastApi["push"];
  go: (id: ScreenId) => void;
}

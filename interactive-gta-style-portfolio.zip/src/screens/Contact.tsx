import { ArrowUpRight, Mail, MapPin, Phone, Radio, Send, Terminal } from "lucide-react";
import { Icon } from "@/lib/icons";
import { Btn, LinkBtn, Panel, Row, ScreenHead, Tag } from "@/components/ui";
import { byId, contact, player } from "@/config/portfolio";
import type { ScreenProps } from "@/screens/types";

export default function Contact({ toast }: ScreenProps) {
  const mail = `mailto:${contact.email}?subject=${encodeURIComponent("New mission — project enquiry")}&body=${encodeURIComponent(
    "Hi Harsh,\n\nI'd like to brief a project:\n\n— Scope:\n— Timeline:\n— Budget range:\n\n",
  )}`;

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-4">
      <ScreenHead
        num="08"
        title="Contact HQ"
        sub={`${byId("contact").sector} · ${contact.location}`}
        right={
          <div className="flex items-center gap-2">
            <Tag tone="accent">
              <Radio size={10} className="anim-blink" /> CHANNEL OPEN
            </Tag>
            <Tag>{contact.responseTime}</Tag>
          </div>
        }
      />

      <div className="scroll-y grid min-h-0 flex-1 grid-cols-1 gap-3 lg:grid-cols-[minmax(280px,400px)_1fr] lg:overflow-hidden">
        {/* channels */}
        <div className="flex flex-col gap-2">
          <span className="label">Transmission Channels</span>

          <LinkBtn href={mail} variant="primary" className="justify-between py-3">
            <span className="flex items-center gap-2">
              <Send size={14} /> Send Message
            </span>
            <ArrowUpRight size={14} />
          </LinkBtn>

          {contact.socials.map((s) => (
            <LinkBtn
              key={s.label}
              href={s.url}
              className="justify-between py-3"
              hint={s.pending ? "Profile URL pending — set it in src/config/portfolio.ts" : undefined}
            >
              <span className="flex items-center gap-2">
                <Icon name={s.icon} size={14} />
                {s.label === "GITHUB" ? "Open GitHub" : s.label === "LINKEDIN" ? "Connect on LinkedIn" : s.label}
              </span>
              <span className="font-mono text-[9px] tracking-[0.12em] text-bone-500">
                {s.pending ? "PENDING" : "LINKED"}
              </span>
            </LinkBtn>
          ))}

          <LinkBtn
            href={contact.phone ? `tel:${contact.phone.replace(/\s/g, "")}` : null}
            className="justify-between py-3"
            hint="Phone number intentionally not published"
            disabled={!contact.phone}
          >
            <span className="flex items-center gap-2">
              <Phone size={14} /> Call
            </span>
            <span className="font-mono text-[9px] tracking-[0.12em]">{contact.phone ?? "ON REQUEST"}</span>
          </LinkBtn>

          <Panel className="mt-1 p-4">
            <span className="label">HQ Coordinates</span>
            <div className="mt-2">
              <Row k="Location" v={contact.location} />
              <Row k="Region" v={player.region} />
              <Row k="Coords" v={player.coords} />
              <Row k="Availability" v={contact.availability} />
              <Row k="Timezone" v={player.timezone} />
            </div>
            <p className="label mt-3 flex items-center gap-1.5">
              <MapPin size={10} /> REMOTE-FIRST · WORKS WITH CLIENTS ANYWHERE
            </p>
          </Panel>
        </div>

        {/* terminal */}
        <Panel className="clip-notch flex min-h-0 flex-col p-4">
          <div className="flex items-center gap-2">
            <Terminal size={14} className="txt-accent" />
            <span className="label">Comms Terminal // Secure Channel</span>
          </div>

          <div className="mt-3">
            <span className="clip-tag inline-flex items-center gap-1.5 border border-[rgba(var(--accent-rgb),0.45)] bg-[rgba(var(--accent-rgb),0.14)] px-2 py-[3px] font-mono text-[9.5px] tracking-[0.2em] txt-accent uppercase">
              New Mission Available
            </span>
            <h3 className="mt-2 font-display text-[clamp(26px,4.4vw,52px)] leading-[0.9] tracking-[0.01em] text-bone-100 uppercase">
              Looking for a
              <br />
              <span className="txt-accent glow-text">Digital Experience?</span>
            </h3>
            <p className="mt-3 max-w-[58ch] text-[13.5px] leading-relaxed text-bone-300">
              Send the brief — what you're building, who it's for, and when it needs to exist. You'll get a real reply
              with scope, timeline and an honest estimate.
            </p>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            <LinkBtn href={mail} variant="primary">
              <Mail size={13} /> Start Communication
            </LinkBtn>
            <Btn onClick={() => toast("TRANSMISSION QUEUED", `Draft opened for ${contact.email}`, "info")}>
              Queue Transmission
            </Btn>
          </div>

          <div className="mt-5 border border-white/[0.08] bg-black/50 p-3">
            <div className="label mb-2">Transmission Log</div>
            <div className="space-y-1 font-mono text-[10.5px] leading-relaxed tracking-[0.06em] text-bone-500">
              <p>
                <span className="txt-accent">&gt;</span> handshake .......... <span className="text-emerald-300">OK</span>
              </p>
              <p>
                <span className="txt-accent">&gt;</span> channel ............ <span className="text-bone-300">{contact.email}</span>
              </p>
              <p>
                <span className="txt-accent">&gt;</span> response window .... <span className="text-bone-300">{contact.responseTime}</span>
              </p>
              <p>
                <span className="txt-accent">&gt;</span> encryption ......... <span className="text-emerald-300">TLS / MAILTO</span>
              </p>
              <p>
                <span className="txt-accent">&gt;</span> awaiting input .....{" "}
                <span className="anim-blink text-bone-100">█</span>
              </p>
            </div>
          </div>

          <p className="label mt-4">
            NO PHONE NUMBER OR ADDRESS PUBLISHED — CONTACT DETAILS COME FROM src/config/portfolio.ts
          </p>
        </Panel>
      </div>
    </div>
  );
}

import { ArrowRight, Play, Radar, Crosshair } from "lucide-react";
import { Bar, Btn, Chip, Panel, Row, ScreenHead, Tag } from "@/components/ui";
import { missions, player, screens, skillBranches } from "@/config/portfolio";
import type { ScreenProps } from "@/screens/types";

export default function Home({ progress, toast, go }: ScreenProps) {
  const topSkills = skillBranches
    .flatMap((b) => b.skills)
    .sort((a, b) => b.level - a.level)
    .slice(0, 6);

  const start = () => {
    toast("MISSION STARTED", "EXPLORE THE PORTFOLIO — SECTOR 02", "mission");
    go("about");
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-4">
      <ScreenHead
        num="01"
        title="World Entry"
        sub={`${screens[0].sector} · ${screens[0].coords} · SYSTEM // ONLINE`}
        right={
          <div className="flex flex-wrap items-center gap-2">
            <Tag tone="accent">
              <Radar size={10} /> {player.status}
            </Tag>
            <Tag>{player.version}</Tag>
          </div>
        }
      />

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-4 lg:grid-cols-[1.35fr_minmax(280px,420px)]">
        {/* ── intro ── */}
        <div className="flex min-h-0 flex-col justify-center gap-4">
          <div>
            <p className="label mb-2">CHARACTER SELECT // SLOT 01</p>
            <h2 className="font-display text-[clamp(44px,9.4vw,124px)] leading-[0.8] tracking-[0.005em] text-bone-100 uppercase">
              {player.first}
              <br />
              <span className="txt-accent glow-text">{player.last}</span>
            </h2>
            <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1">
              <span className="font-cond text-[clamp(15px,2.1vw,24px)] tracking-[0.3em] uppercase" style={{ color: "var(--accent)" }}>
                {player.title}
              </span>
              <span className="hidden h-4 w-px bg-white/20 sm:block" />
              <span className="label">{player.class}</span>
            </div>
            <p className="mt-4 max-w-[52ch] font-cond text-[clamp(13px,1.5vw,17px)] leading-relaxed tracking-[0.09em] text-bone-300 uppercase">
              {player.tagline}
            </p>
          </div>

          {/* mission card */}
          <Panel accent className="clip-notch max-w-[520px] p-4">
            <div className="flex items-center justify-between">
              <span className="label txt-accent">Current Mission</span>
              <span className="label">M-000</span>
            </div>
            <h3 className="mt-1 font-display text-[26px] leading-none tracking-[0.02em] text-bone-100 uppercase sm:text-[32px]">
              Explore the Portfolio
            </h3>
            <p className="mt-2 max-w-[44ch] text-[13px] leading-relaxed text-bone-300">
              Nine sectors. One player. Walk the world — every sector you open raises your reputation and stays saved
              on this device.
            </p>
            <div className="mt-4 flex flex-wrap items-center gap-2">
              <Btn variant="primary" onClick={start}>
                <Play size={13} /> Start
              </Btn>
              <Btn onClick={() => go("projects")}>
                View Projects <ArrowRight size={13} />
              </Btn>
              <Btn onClick={() => go("contact")}>
                <Crosshair size={13} /> Contact HQ
              </Btn>
            </div>
          </Panel>

          <p className="label">
            ◀ ▶ SWITCH SECTOR · 1–9 JUMP · ↑ ↓ SELECT · ENTER OPEN · ESC RETURN
          </p>
        </div>

        {/* ── snapshot rail ── */}
        <div className="flex min-h-0 flex-col gap-3">
          <Panel className="p-4">
            <div className="flex items-center justify-between">
              <span className="label">Player Snapshot</span>
              <span className="font-mono text-[10px] tracking-[0.14em] txt-accent">{player.playerId}</span>
            </div>
            <div className="mt-2">
              <Row k="Level" v={`${player.level}`} />
              <Row k="Class" v={player.class} />
              <Row k="Location" v={player.location} />
              <Row k="Timezone" v={player.timezone} />
              <Row k="Sectors found" v={`${progress.visited.size} / ${screens.length}`} />
              <Row k="Missions logged" v={`${progress.openedMissions.size} / ${missions.length}`} />
            </div>
          </Panel>

          <Panel className="p-4" accent>
            <div className="flex items-end justify-between">
              <span className="label">Portfolio Completion</span>
              <span className="font-display text-[30px] leading-none text-bone-100 tabular-nums">
                {progress.completion}
                <span className="txt-accent">%</span>
              </span>
            </div>
            <Bar value={progress.completion} className="mt-2" />
            <p className="label mt-2">Progress saved locally — save slot 01</p>
          </Panel>

          <Panel className="p-4">
            <div className="flex items-center justify-between">
              <span className="label">Skills Summary</span>
              <span className="label">{progress.totals.skills} UNLOCKED</span>
            </div>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {topSkills.map((s) => (
                <Chip key={s.name}>
                  {s.name} · LVL {String(s.level).padStart(2, "0")}
                </Chip>
              ))}
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}

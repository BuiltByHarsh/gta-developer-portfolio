import { useState } from "react";
import { GraduationCap, Heart, Sparkles, Target, User } from "lucide-react";
import { Bar, Chip, ListRow, Meter, Panel, Row, ScreenHead, Split, Tag } from "@/components/ui";
import { byId, education, player, stats, attributes } from "@/config/portfolio";
import type { ScreenProps } from "@/screens/types";

type RecordId = "bio" | "education" | "strengths" | "interests" | "direction";

const records: { id: RecordId; label: string; meta: string; icon: typeof User }[] = [
  { id: "bio", label: "BIOGRAPHY", meta: "3 ENTRIES", icon: User },
  { id: "education", label: "EDUCATION", meta: `${education.length} RECORDS`, icon: GraduationCap },
  { id: "strengths", label: "STRENGTHS", meta: `${player.strengths.length} TRAITS`, icon: Target },
  { id: "interests", label: "INTERESTS", meta: `${player.interests.length} TAGS`, icon: Heart },
  { id: "direction", label: "DIRECTION", meta: "CAREER VECTOR", icon: Sparkles },
];

export default function About({ toast }: ScreenProps) {
  const [active, setActive] = useState<RecordId>("bio");

  const select = (id: RecordId) => {
    setActive(id);
    toast("PROFILE RECORD OPENED", records.find((r) => r.id === id)?.label, "info", 2000);
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-4">
      <ScreenHead
        num="02"
        title="Player Profile"
        sub={`${byId("about").sector} · ${byId("about").coords}`}
        right={
          <div className="flex items-center gap-2">
            <Tag tone="accent">PLAYER ID: {player.playerId}</Tag>
            <Tag>RECORD // {player.handle}</Tag>
          </div>
        }
      />

      <Split
        list={
          <>
            {/* character card */}
            <Panel className="clip-notch overflow-hidden">
              <div className="relative h-[132px] w-full overflow-hidden">
                <img
                  src={byId("about").image}
                  alt=""
                  className="h-full w-full object-cover object-[35%_30%] opacity-80"
                  style={{ maskImage: "linear-gradient(to bottom, black 40%, transparent 100%)" }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-900 via-transparent to-transparent" />
                <div className="absolute bottom-2 left-3">
                  <div className="font-display text-[22px] leading-none text-bone-100 uppercase">{player.name}</div>
                  <div className="label mt-1">{player.class}</div>
                </div>
                <span className="absolute top-2 right-2 clip-tag border border-white/15 bg-black/70 px-2 py-[2px] font-mono text-[9px] tracking-[0.16em] txt-accent">
                  HS-001
                </span>
              </div>
              <div className="px-3 py-2">
                <Row k="Level" v={player.level} />
                <Row k="Home region" v={player.region} />
                <Row k="Status" v={player.status} />
              </div>
            </Panel>

            <p className="label px-1 pt-2">Profile Records</p>
            {records.map((r, i) => {
              const I = r.icon;
              return (
                <ListRow
                  key={r.id}
                  index={String(i + 1).padStart(2, "0")}
                  title={r.label}
                  meta={r.meta}
                  active={active === r.id}
                  onSelect={() => select(r.id)}
                  right={<I size={14} className={active === r.id ? "txt-accent" : "text-bone-500"} />}
                />
              );
            })}
          </>
        }
        detail={
          <div className="flex flex-col gap-3">
            {/* stats */}
            <Panel className="p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="label">Player Stats</span>
                <span className="label">DERIVED FROM ACTUAL WORK</span>
              </div>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                {stats.map((s) => (
                  <div key={s.label}>
                    <div className="flex items-baseline justify-between">
                      <span className="font-cond text-[12.5px] tracking-[0.16em] text-bone-100 uppercase">{s.label}</span>
                      <span className="font-mono text-[10px] txt-accent">{s.value}</span>
                    </div>
                    <Meter value={s.value} className="mt-1.5" />
                    <p className="label mt-1">{s.note}</p>
                  </div>
                ))}
                <div className="sm:col-span-2">
                  <div className="flex flex-wrap gap-x-6 gap-y-2">
                    {attributes.map((a) => (
                      <div key={a.label} className="min-w-[110px] flex-1">
                        <div className="flex items-baseline justify-between">
                          <span className="label">{a.label}</span>
                          <span className="font-mono text-[9.5px] text-bone-500">{a.value}</span>
                        </div>
                        <Bar value={a.value} className="mt-1" />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </Panel>

            {active === "bio" && (
              <Panel className="p-4">
                <span className="label">Biography</span>
                <div className="mt-2 space-y-3">
                  {player.bio.map((p, i) => (
                    <p key={i} className="max-w-[70ch] text-[13.5px] leading-relaxed text-bone-300">
                      <span className="mr-2 font-mono text-[10px] txt-accent">{String(i + 1).padStart(2, "0")}</span>
                      {p}
                    </p>
                  ))}
                </div>
              </Panel>
            )}

            {active === "education" && (
              <div className="flex flex-col gap-3">
                {education.map((e) => (
                  <Panel key={e.id} className="p-4" accent={e.status === "ACTIVE"}>
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="label">{e.id}</span>
                      <Tag tone={e.status === "ACTIVE" ? "accent" : "warn"}>{e.status}</Tag>
                    </div>
                    <h3 className="mt-1 font-cond text-[17px] tracking-[0.1em] text-bone-100 uppercase">{e.degree}</h3>
                    <p className="label mt-0.5">{e.field}</p>
                    <div className="mt-3">
                      <Row k="Institution" v={e.institution} />
                      <Row k="Period" v={e.period} />
                    </div>
                    <p className="mt-2 max-w-[68ch] text-[13px] leading-relaxed text-bone-300">{e.note}</p>
                  </Panel>
                ))}
              </div>
            )}

            {active === "strengths" && (
              <Panel className="p-4">
                <span className="label">Personal Strengths</span>
                <ul className="mt-3 space-y-2">
                  {player.strengths.map((s) => (
                    <li key={s} className="flex gap-3 text-[13.5px] text-bone-300">
                      <span className="mt-[6px] h-[6px] w-[6px] shrink-0 bg-[var(--accent)]" />
                      {s}
                    </li>
                  ))}
                </ul>
              </Panel>
            )}

            {active === "interests" && (
              <Panel className="p-4">
                <span className="label">Interests</span>
                <div className="mt-3 flex flex-wrap gap-2">
                  {player.interests.map((i) => (
                    <Chip key={i}>{i}</Chip>
                  ))}
                </div>
              </Panel>
            )}

            {active === "direction" && (
              <Panel className="p-4" accent>
                <span className="label">Career Direction</span>
                <p className="mt-2 max-w-[66ch] font-cond text-[15px] leading-relaxed tracking-[0.06em] text-bone-100 uppercase">
                  {player.direction}
                </p>
              </Panel>
            )}
          </div>
        }
      />
    </div>
  );
}

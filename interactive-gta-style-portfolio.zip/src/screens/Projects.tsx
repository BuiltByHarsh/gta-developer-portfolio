import { useState } from "react";
import { ArrowUpRight, Code2, ExternalLink, Play } from "lucide-react";
import { Btn, Chip, LinkBtn, ListRow, Panel, Row, ScreenHead, Split, Tag } from "@/components/ui";
import { byId, github, missions, type Mission } from "@/config/portfolio";
import { GithubMark } from "@/lib/icons";
import type { ScreenProps } from "@/screens/types";

const statusTone = (s: Mission["status"]): "accent" | "warn" | "mute" =>
  s === "COMPLETED" ? "accent" : s === "IN PROGRESS" ? "warn" : "mute";

export default function Projects({ progress, toast }: ScreenProps) {
  const [activeId, setActiveId] = useState(missions[0].id);
  const mission = missions.find((m) => m.id === activeId)!;

  const select = (m: Mission) => {
    setActiveId(m.id);
    const fresh = !progress.openedMissions.has(m.id);
    progress.markMission(m.id);
    toast(fresh ? "NEW MISSION DISCOVERED" : "MISSION FILE OPEN", `${m.code} — ${m.title}`, "mission", 2600);
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-4">
      <ScreenHead
        num="04"
        title="Mission Database"
        sub={`${byId("projects").sector} · ${missions.length} MISSIONS · ${progress.openedMissions.size} OPENED`}
        right={
          <div className="flex items-center gap-2">
            <Tag tone="accent">DATABASE // SYNCED</Tag>
            <Tag>{progress.totals.missionsCompleted} COMPLETED</Tag>
          </div>
        }
      />

      <Split
        list={
          <>
            {missions.map((m, i) => (
              <ListRow
                key={m.id}
                index={String(i + 1).padStart(2, "0")}
                title={m.title}
                meta={`${m.code} · ${m.type}`}
                active={m.id === activeId}
                onSelect={() => select(m)}
                right={
                  <span
                    className="shrink-0 font-mono text-[8.5px] tracking-[0.14em] uppercase"
                    style={{ color: m.status === "COMPLETED" ? "var(--accent)" : "#FCD34D" }}
                  >
                    {m.status}
                  </span>
                }
              />
            ))}

            <Panel className="mt-2 p-4">
              <div className="flex items-center gap-2">
                <span className="txt-accent">
                  <GithubMark size={14} />
                </span>
                <span className="label">GitHub // Player Repository</span>
              </div>
              <p className="mt-2 text-[12.5px] leading-relaxed text-bone-300">{github.note}</p>
              <div className="mt-3">
                <LinkBtn href={github.profile} className="w-full justify-center">
                  Open GitHub Profile <ArrowUpRight size={13} />
                </LinkBtn>
              </div>
            </Panel>
          </>
        }
        detail={
          <div className="flex flex-col gap-3">
            {/* mission brief */}
            <Panel className="clip-notch p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[10px] tracking-[0.2em] txt-accent">{mission.code}</span>
                    <Tag tone={statusTone(mission.status)}>{mission.status}</Tag>
                    <Tag>{mission.year}</Tag>
                  </div>
                  <h3 className="mt-1 font-display text-[clamp(24px,3.4vw,40px)] leading-[0.95] tracking-[0.01em] text-bone-100 uppercase">
                    {mission.title}
                  </h3>
                </div>
                <div className="text-right">
                  <div className="label">Reward</div>
                  <div className="font-display text-[24px] leading-none" style={{ color: "var(--accent)" }}>
                    {mission.xp.toLocaleString("en-US")} XP
                  </div>
                </div>
              </div>

              <div className="mt-3 border-l-2 pl-3" style={{ borderColor: "var(--accent)" }}>
                <div className="label">Objective</div>
                <p className="font-cond text-[15px] tracking-[0.05em] text-bone-100 uppercase">{mission.objective}</p>
              </div>

              <p className="mt-3 max-w-[70ch] text-[13.5px] leading-relaxed text-bone-300">{mission.brief}</p>

              <div className="mt-4 grid gap-x-6 sm:grid-cols-2">
                <Row k="Type" v={mission.type} />
                <Row k="Role" v={mission.role} />
                <Row k="Difficulty" v={mission.difficulty} />
                <Row k="Deployed" v={mission.live ? "YES" : "LINK PENDING"} />
              </div>

              <div className="mt-4">
                <span className="label">Deliverables</span>
                <ul className="mt-2 grid gap-1.5 sm:grid-cols-2">
                  {mission.deliverables.map((d) => (
                    <li key={d} className="flex gap-2 text-[12.5px] text-bone-300">
                      <span className="mt-[6px] h-[5px] w-[5px] shrink-0 bg-[var(--accent)]" />
                      {d}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-4 flex flex-wrap gap-1.5">
                {mission.tech.map((t) => (
                  <Chip key={t}>{t}</Chip>
                ))}
              </div>

              <div className="mt-5 flex flex-wrap gap-2">
                <Btn variant="primary" onClick={() => toast("MISSION BRIEF OPEN", `${mission.code} — ${mission.title}`, "mission")}>
                  <Play size={13} /> View Mission
                </Btn>
                <LinkBtn href={mission.live} hint="Live URL not set in config yet">
                  Live Site <ExternalLink size={13} />
                </LinkBtn>
                <LinkBtn href={mission.repo} hint="Repository URL not set in config yet">
                  <Code2 size={13} /> Source Code
                </LinkBtn>
              </div>
            </Panel>

            {/* repository list */}
            <Panel className="p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="label">Repositories // Mission Records</span>
                <span className="label">{github.handle}</span>
              </div>
              <div className="mt-3 flex flex-col gap-2">
                {missions.map((m, i) => (
                  <div
                    key={m.id}
                    className="flex flex-wrap items-center justify-between gap-3 border border-white/[0.07] bg-white/[0.02] px-3 py-2"
                  >
                    <div className="min-w-0">
                      <div className="font-cond text-[12.5px] tracking-[0.14em] text-bone-100 uppercase">
                        REPOSITORY #{String(i + 1).padStart(3, "0")} · {m.title}
                      </div>
                      <div className="label mt-0.5">{m.tech.slice(0, 4).join(" / ")}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Tag tone={m.status === "COMPLETED" ? "accent" : "warn"}>
                        {m.status === "COMPLETED" ? "ACTIVE" : "IN PROGRESS"}
                      </Tag>
                      <LinkBtn href={m.repo} className="px-3 py-1.5 text-[10.5px]" hint="Repository URL pending">
                        View Repository
                      </LinkBtn>
                    </div>
                  </div>
                ))}
              </div>
            </Panel>
          </div>
        }
      />
    </div>
  );
}

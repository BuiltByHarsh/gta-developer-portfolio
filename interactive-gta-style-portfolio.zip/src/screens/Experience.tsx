import { useState } from "react";
import { CalendarClock, CheckCircle2 } from "lucide-react";
import { Chip, ListRow, Panel, Row, ScreenHead, Split, Tag } from "@/components/ui";
import { byId, experience, type ExperienceEntry } from "@/config/portfolio";
import type { ScreenProps } from "@/screens/types";

export default function Experience({ toast }: ScreenProps) {
  const [activeId, setActiveId] = useState(experience[0].id);
  const entry = experience.find((e) => e.id === activeId)!;

  const select = (e: ExperienceEntry) => {
    setActiveId(e.id);
    toast(e.status === "CURRENT" ? "MISSION IN PROGRESS" : "MISSION COMPLETED", `${e.year} — ${e.role}`, "complete", 2600);
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-4">
      <ScreenHead
        num="05"
        title="Mission History"
        sub={`${byId("experience").sector} · ${experience.length} LOGGED ENTRIES · 2024 → PRESENT`}
        right={
          <div className="flex items-center gap-2">
            <Tag tone="accent">
              <CalendarClock size={10} /> TIMELINE ACTIVE
            </Tag>
            <Tag>LOG // HS-001</Tag>
          </div>
        }
      />

      <Split
        list={
          <>
            {experience.map((e) => (
              <ListRow
                key={e.id}
                index={e.year}
                title={e.role}
                meta={`${e.org} · ${e.type}`}
                active={e.id === activeId}
                onSelect={() => select(e)}
                right={
                  <span
                    className="shrink-0 font-mono text-[8.5px] tracking-[0.14em] uppercase"
                    style={{ color: e.status === "CURRENT" ? "var(--accent)" : "#6EE7B7" }}
                  >
                    {e.status}
                  </span>
                }
              />
            ))}

            <Panel className="mt-2 p-4">
              <span className="label">Career Vector</span>
              <div className="relative mt-3 pl-4">
                <span className="absolute top-1 bottom-1 left-0 w-px bg-white/12" />
                {experience.map((e) => (
                  <div key={e.id} className="relative pb-3 last:pb-0">
                    <span
                      className="absolute top-1.5 -left-[19px] h-2 w-2 rotate-45"
                      style={{ background: e.id === activeId ? "var(--accent)" : "rgba(255,255,255,0.3)" }}
                    />
                    <div className="font-mono text-[10px] tracking-[0.16em] text-bone-500">{e.year}</div>
                    <div className="font-cond text-[12.5px] tracking-[0.1em] text-bone-100 uppercase">{e.role}</div>
                  </div>
                ))}
              </div>
              <p className="label mt-2">
                NO EMPLOYER RECORDS INVENTED — ONLY VERIFIED WORK APPEARS HERE.
              </p>
            </Panel>
          </>
        }
        detail={
          <Panel className="clip-notch p-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-display text-[26px] leading-none txt-accent">{entry.year}</span>
                  <Tag tone={entry.status === "CURRENT" ? "accent" : "mute"}>{entry.status}</Tag>
                </div>
                <h3 className="mt-1 font-display text-[clamp(22px,3vw,36px)] leading-[0.95] tracking-[0.01em] text-bone-100 uppercase">
                  {entry.role}
                </h3>
                <p className="label mt-1">
                  {entry.org} · {entry.type}
                </p>
              </div>
              {entry.status === "CURRENT" ? (
                <span className="clip-tag flex items-center gap-1.5 border border-[var(--accent)] bg-[rgba(var(--accent-rgb),0.14)] px-2 py-1 font-mono text-[9.5px] tracking-[0.18em] txt-accent uppercase">
                  <span className="h-1.5 w-1.5 anim-blink bg-[var(--accent)]" /> LIVE
                </span>
              ) : (
                <span className="clip-tag flex items-center gap-1.5 border border-emerald-300/30 bg-emerald-400/10 px-2 py-1 font-mono text-[9.5px] tracking-[0.18em] text-emerald-200 uppercase">
                  <CheckCircle2 size={11} /> PASSED
                </span>
              )}
            </div>

            <p className="mt-3 max-w-[70ch] text-[13.5px] leading-relaxed text-bone-300">{entry.summary}</p>

            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <div>
                <span className="label">Responsibilities</span>
                <ul className="mt-2 space-y-1.5">
                  {entry.duties.map((d) => (
                    <li key={d} className="flex gap-2 text-[12.5px] text-bone-300">
                      <span className="mt-[6px] h-[5px] w-[5px] shrink-0 bg-[var(--accent)]" />
                      {d}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <span className="label">Key Wins</span>
                <ul className="mt-2 space-y-1.5">
                  {entry.wins.map((w) => (
                    <li key={w} className="flex gap-2 text-[12.5px] text-bone-300">
                      <span className="mt-[5px] font-mono text-[10px] txt-accent">✓</span>
                      {w}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="mt-4">
              <Row k="Stack" v={entry.tech.join(" / ")} />
              <Row k="Record ID" v={`${entry.id.toUpperCase()} · HS-001`} />
            </div>

            <div className="mt-3 flex flex-wrap gap-1.5">
              {entry.tech.map((t) => (
                <Chip key={t}>{t}</Chip>
              ))}
            </div>
          </Panel>
        }
      />
    </div>
  );
}

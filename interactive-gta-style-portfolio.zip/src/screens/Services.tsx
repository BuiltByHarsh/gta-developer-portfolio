import { useState } from "react";
import { ArrowRight, Clock, FileCheck2, Handshake } from "lucide-react";
import { Btn, ListRow, Panel, Row, ScreenHead, Split, Tag } from "@/components/ui";
import { byId, contracts, type Contract } from "@/config/portfolio";
import { Icon } from "@/lib/icons";
import type { ScreenProps } from "@/screens/types";

export default function Services({ progress, toast, go }: ScreenProps) {
  const [activeId, setActiveId] = useState(contracts[0].id);
  const contract = contracts.find((c) => c.id === activeId)!;
  const taken = progress.takenContracts.has(contract.id);

  const accept = (c: Contract) => {
    progress.markContract(c.id);
    toast("CONTRACT ACCEPTED", `${c.code} — routing to CONTACT HQ`, "mission");
    window.setTimeout(() => go("contact"), 620);
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-4">
      <ScreenHead
        num="07"
        title="Available Contracts"
        sub={`${byId("services").sector} · ${contracts.length} OPEN · ${progress.takenContracts.size} ACCEPTED`}
        right={
          <div className="flex items-center gap-2">
            <Tag tone="accent">
              <Handshake size={10} /> BOARD // OPEN
            </Tag>
            <Tag>REMOTE · WORLDWIDE</Tag>
          </div>
        }
      />

      <Split
        list={
          <>
            {contracts.map((c, i) => (
              <ListRow
                key={c.id}
                index={String(i + 1).padStart(2, "0")}
                title={c.title}
                meta={`${c.code} · ${c.scope}`}
                active={c.id === activeId}
                onSelect={() => setActiveId(c.id)}
                right={
                  <span
                    className="shrink-0 font-mono text-[8.5px] tracking-[0.14em] uppercase"
                    style={{ color: c.status === "AVAILABLE" ? "var(--accent)" : "#FCD34D" }}
                  >
                    {c.status}
                  </span>
                }
              />
            ))}

            <Panel className="mt-2 p-4">
              <span className="label">How Contracts Work</span>
              <ol className="mt-2 space-y-1.5 text-[12.5px] text-bone-300">
                <li>
                  <span className="mr-2 font-mono text-[10px] txt-accent">01</span>Brief the mission at CONTACT HQ
                </li>
                <li>
                  <span className="mr-2 font-mono text-[10px] txt-accent">02</span>Scope, timeline and estimate returned
                </li>
                <li>
                  <span className="mr-2 font-mono text-[10px] txt-accent">03</span>Build in passes — you review each one
                </li>
                <li>
                  <span className="mr-2 font-mono text-[10px] txt-accent">04</span>Deploy, hand off, document
                </li>
              </ol>
            </Panel>
          </>
        }
        detail={
          <Panel className="clip-notch p-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center border border-[rgba(var(--accent-rgb),0.4)] bg-black/40 txt-accent">
                  <Icon name={contract.icon} size={19} />
                </span>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[10px] tracking-[0.2em] txt-accent">{contract.code}</span>
                    <Tag tone={contract.status === "AVAILABLE" ? "accent" : "warn"}>{contract.status}</Tag>
                  </div>
                  <h3 className="mt-1 font-display text-[clamp(22px,3vw,36px)] leading-[0.95] tracking-[0.01em] text-bone-100 uppercase">
                    {contract.title}
                  </h3>
                </div>
              </div>
              <div className="text-right">
                <div className="label">Scope</div>
                <div className="font-cond text-[13px] tracking-[0.16em] text-bone-100 uppercase">{contract.scope}</div>
              </div>
            </div>

            <p className="mt-3 max-w-[68ch] font-cond text-[14.5px] leading-relaxed tracking-[0.05em] text-bone-300 uppercase">
              {contract.summary}
            </p>

            <div className="mt-4">
              <span className="label">Contract Includes</span>
              <ul className="mt-2 grid gap-1.5 sm:grid-cols-2">
                {contract.includes.map((inc) => (
                  <li key={inc} className="flex items-center gap-2 border border-white/[0.07] bg-white/[0.02] px-3 py-2 text-[12.5px] text-bone-300">
                    <FileCheck2 size={12} className="shrink-0 txt-accent" />
                    {inc}
                  </li>
                ))}
              </ul>
            </div>

            <div className="mt-4 grid gap-x-6 sm:grid-cols-2">
              <Row
                k="Turnaround"
                v={
                  <span className="flex items-center justify-end gap-1.5">
                    <Clock size={11} className="txt-accent" /> {contract.turnaround}
                  </span>
                }
              />
              <Row k="Contract status" v={taken ? "ACCEPTED — AWAITING BRIEF" : "OPEN FOR BRIEF"} />
            </div>

            <div className="mt-5 flex flex-wrap gap-2">
              <Btn variant="primary" onClick={() => accept(contract)}>
                {taken ? "Re-open Contract" : "Accept Contract"} <ArrowRight size={13} />
              </Btn>
              <Btn onClick={() => go("contact")}>Go to Contact HQ</Btn>
            </div>
          </Panel>
        }
      />
    </div>
  );
}

import { useState } from "react";
import { GitFork, Layers, Zap } from "lucide-react";
import { Icon } from "@/lib/icons";
import { ListRow, Meter, Panel, ScreenHead, Split, Tag } from "@/components/ui";
import { byId, skillBranches, type Skill } from "@/config/portfolio";
import { sound } from "@/lib/audio";
import type { ScreenProps } from "@/screens/types";

export default function Skills({ progress, toast }: ScreenProps) {
  const [branchId, setBranchId] = useState(skillBranches[0].id);
  const [inspected, setInspected] = useState<string | null>(null);
  const branch = skillBranches.find((b) => b.id === branchId)!;
  const totalSkills = progress.totals.skills;
  const avg = Math.round(
    (skillBranches.flatMap((b) => b.skills).reduce((a, s) => a + s.level, 0) / totalSkills) * 10,
  );

  const inspect = (s: Skill) => {
    setInspected(s.name);
    sound.play("notify");
    toast("SKILL INSPECTED", `${s.name} — LEVEL ${String(s.level).padStart(2, "0")}`, "unlock", 2200);
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-4">
      <ScreenHead
        num="03"
        title="Skill Tree"
        sub={`${byId("skills").sector} · ${totalSkills} SKILLS · AVG LVL ${(avg / 10).toFixed(1)}`}
        right={
          <div className="flex items-center gap-2">
            <Tag tone="accent">
              <Zap size={10} /> SYNCED
            </Tag>
            <Tag>3 BRANCHES</Tag>
          </div>
        }
      />

      <Split
        list={
          <>
            {skillBranches.map((b, i) => (
              <ListRow
                key={b.id}
                index={String(i + 1).padStart(2, "0")}
                title={b.name}
                meta={`${b.skills.length} SKILLS`}
                active={b.id === branchId}
                onSelect={() => setBranchId(b.id)}
                right={
                  i === 0 ? (
                    <GitFork size={14} className={b.id === branchId ? "txt-accent" : "text-bone-500"} />
                  ) : i === 1 ? (
                    <Layers size={14} className={b.id === branchId ? "txt-accent" : "text-bone-500"} />
                  ) : (
                    <Zap size={14} className={b.id === branchId ? "txt-accent" : "text-bone-500"} />
                  )
                }
              />
            ))}

            <Panel className="mt-2 p-4">
              <span className="label">Branch Intel</span>
              <p className="mt-2 max-w-[34ch] text-[13px] leading-relaxed text-bone-300">{branch.tagline}</p>
              <p className="label mt-3">
                LEVELS ARE QUALITATIVE — SELF-ASSESSED AGAINST SHIPPED WORK, NOT CLAIMED CERTIFICATION.
              </p>
            </Panel>
          </>
        }
        detail={
          <div className="flex flex-col gap-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="font-display text-[22px] leading-none tracking-[0.02em] text-bone-100 uppercase sm:text-[28px]">
                {branch.name}
              </h3>
              <span className="label">{branch.skills.length} NODES · CLICK TO INSPECT</span>
            </div>

            {branch.skills.map((s, i) => (
              <button
                key={s.name}
                type="button"
                data-item=""
                data-cursor="link"
                onMouseEnter={() => sound.play("hover")}
                onClick={() => inspect(s)}
                className="hover-lift group relative w-full border border-white/[0.08] bg-white/[0.025] p-3 text-left transition-colors hover:border-[var(--accent)] hover:bg-[rgba(var(--accent-rgb),0.10)]"
              >
                <span
                  className="absolute inset-y-0 left-0 w-[2px] origin-top scale-y-0 bg-[var(--accent)] transition-transform duration-300 group-hover:scale-y-100"
                  aria-hidden="true"
                />
                <div className="flex items-center gap-3">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center border border-white/10 bg-black/40 text-bone-300 transition-colors group-hover:border-[var(--accent)] group-hover:txt-accent">
                    <Icon name={s.icon} size={15} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-baseline justify-between gap-x-3">
                      <span className="font-cond text-[14.5px] tracking-[0.12em] text-bone-100 uppercase">{s.name}</span>
                      <span className="font-mono text-[10px] tracking-[0.14em] txt-accent">
                        LEVEL {String(s.level).padStart(2, "0")} · {s.level * 10}%
                      </span>
                    </div>
                    <Meter value={s.level * 10} className="mt-2" />
                    <p className="label mt-1.5 truncate">{s.note}</p>
                  </div>
                  <span className="hidden font-mono text-[9px] tracking-[0.14em] text-bone-500 sm:block">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                </div>
                {inspected === s.name && (
                  <span className="label mt-2 block txt-accent">▸ NODE INSPECTED</span>
                )}
              </button>
            ))}
          </div>
        }
      />
    </div>
  );
}

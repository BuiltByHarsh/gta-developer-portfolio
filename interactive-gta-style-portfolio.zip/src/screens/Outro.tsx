import { useState } from "react";
import { CheckCircle2, Home, LogOut, RotateCcw } from "lucide-react";
import { Btn, Panel, ScreenHead, Tag } from "@/components/ui";
import { byId, player, screens } from "@/config/portfolio";
import type { ScreenProps } from "@/screens/types";

export default function Outro({ progress, toast, go }: ScreenProps) {
  const [exited, setExited] = useState(false);
  const complete = progress.completion >= 100;

  const stats = [
    { label: "Missions Completed", value: `${progress.totals.missionsCompleted}/${progress.totals.missions}` },
    { label: "Projects Discovered", value: `${progress.openedMissions.size}/${progress.totals.missions}` },
    { label: "Skills Unlocked", value: `${progress.totals.skills}` },
    { label: "Achievements", value: `${progress.totals.unlocked}/${progress.totals.achievements}` },
    { label: "Sectors Explored", value: `${progress.visited.size}/${screens.length}` },
    { label: "Contracts Taken", value: `${progress.takenContracts.size}/${progress.totals.contracts}` },
  ];

  const exit = () => {
    toast("MISSION PASSED", "Session closed — thank you for playing", "complete");
    window.setTimeout(() => setExited(true), 500);
  };

  if (exited) {
    return (
      <div className="fixed inset-0 z-[120] flex flex-col items-center justify-center gap-5 bg-ink-950/97 px-6 text-center">
        <div className="scanlines pointer-events-none absolute inset-0" />
        <p className="label txt-accent">SESSION ENDED</p>
        <h2 className="font-display text-[clamp(34px,8vw,86px)] leading-[0.85] text-bone-100 uppercase">
          Thanks for playing
          <br />
          <span className="txt-accent glow-text">{player.name}</span>
        </h2>
        <p className="max-w-[46ch] text-[13.5px] leading-relaxed text-bone-300">
          Your progress stays saved on this device. Close the tab whenever you're ready — or step back into the world.
        </p>
        <div className="flex flex-wrap items-center justify-center gap-2">
          <Btn
            variant="primary"
            onClick={() => {
              setExited(false);
              go("home");
            }}
          >
            <Home size={13} /> Re-enter World
          </Btn>
        </div>
      </div>
    );
  }

  return (
    <div className="scroll-y flex min-h-0 flex-1 flex-col gap-4">
      <ScreenHead
        num="09"
        title="Mission Complete"
        sub={`${byId("outro").sector} · SESSION SUMMARY`}
        right={
          <div className="flex items-center gap-2">
            <Tag tone="accent">
              <CheckCircle2 size={10} /> {complete ? "100% COMPLETE" : `${progress.completion}% COMPLETE`}
            </Tag>
            <Tag>SAVE SLOT 01</Tag>
          </div>
        }
      />

      <div className="grid min-h-0 gap-3 lg:grid-cols-[1.2fr_minmax(280px,420px)]">
        <div className="flex flex-col justify-center gap-3">
          <div>
            <p className="label mb-2">FINAL REPORT</p>
            <h2 className="font-display text-[clamp(38px,7.4vw,96px)] leading-[0.82] tracking-[0.005em] text-bone-100 uppercase">
              Mission
              <br />
              <span className="txt-accent glow-text">Complete</span>
            </h2>
            <p className="mt-3 max-w-[52ch] font-cond text-[clamp(13px,1.5vw,17px)] leading-relaxed tracking-[0.09em] text-bone-300 uppercase">
              Thank you for exploring {player.first}'s world. Every sector you opened is logged — the save stays on
              this device until you clear it.
            </p>
          </div>

          <div className="flex items-end gap-3">
            <span className="font-display text-[clamp(46px,8vw,84px)] leading-[0.8] text-bone-100 tabular-nums">
              {progress.completion}
              <span className="txt-accent">%</span>
            </span>
            <span className="label pb-2">Portfolio completion</span>
          </div>

          <div className="flex flex-wrap gap-2">
            <Btn variant="primary" onClick={() => go("home")}>
              <Home size={13} /> Return to Main Menu
            </Btn>
            <Btn onClick={exit}>
              <LogOut size={13} /> Exit Portfolio
            </Btn>
            <Btn
              variant="danger"
              onClick={() => {
                progress.reset();
                toast("SAVE DATA CLEARED", "Progress reset to 0%", "save");
              }}
            >
              <RotateCcw size={13} /> Clear Save
            </Btn>
          </div>
        </div>

        <Panel className="p-4">
          <div className="flex items-center justify-between">
            <span className="label">Session Statistics</span>
            <span className="font-mono text-[10px] tracking-[0.14em] txt-accent">{player.playerId}</span>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2">
            {stats.map((s) => (
              <div key={s.label} className="border border-white/[0.08] bg-white/[0.02] p-3">
                <div className="font-display text-[26px] leading-none text-bone-100 tabular-nums">{s.value}</div>
                <div className="label mt-1.5">{s.label}</div>
              </div>
            ))}
          </div>
          <div className="mt-3 border-t border-white/[0.08] pt-3">
            <div className="flex items-baseline justify-between">
              <span className="label">Portfolio Value</span>
              <span className="font-cond text-[18px] tracking-[0.1em]" style={{ color: "var(--accent)" }}>
                $ {progress.xp.toLocaleString("en-US")}
              </span>
            </div>
            <p className="label mt-2">
              {complete
                ? "ALL SECTORS DISCOVERED — FULL MAP REVEALED."
                : "EXPLORE MORE SECTORS, MISSIONS AND CONTRACTS TO REACH 100%."}
            </p>
          </div>
        </Panel>
      </div>
    </div>
  );
}

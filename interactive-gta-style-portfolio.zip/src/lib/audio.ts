/* Tiny WebAudio synth — no audio files, no autoplay. Sound only ever starts
   after an explicit user gesture flips the toggle on. */

type Cue = "hover" | "select" | "switch" | "unlock" | "notify" | "deny" | "start" | "complete";

class SoundEngine {
  private ctx: AudioContext | null = null;
  enabled = false;

  setEnabled(on: boolean) {
    this.enabled = on;
    if (on) this.boot();
  }

  private boot() {
    if (typeof window === "undefined") return;
    if (!this.ctx) {
      const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!Ctor) return;
      this.ctx = new Ctor();
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  private tone(freq: number, at: number, dur: number, type: OscillatorType, gain: number, slideTo?: number) {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, at);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, at + dur);
    g.gain.setValueAtTime(0.0001, at);
    g.gain.exponentialRampToValueAtTime(gain, at + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, at + dur);
    osc.connect(g).connect(this.ctx.destination);
    osc.start(at);
    osc.stop(at + dur + 0.02);
  }

  play(cue: Cue) {
    if (!this.enabled) return;
    this.boot();
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    switch (cue) {
      case "hover":
        this.tone(1180, t, 0.045, "square", 0.022);
        break;
      case "select":
        this.tone(520, t, 0.07, "square", 0.05);
        this.tone(780, t + 0.055, 0.09, "square", 0.04);
        break;
      case "switch":
        this.tone(220, t, 0.16, "sawtooth", 0.045, 660);
        this.tone(880, t + 0.02, 0.1, "sine", 0.03);
        break;
      case "unlock":
        [523, 659, 784, 1046].forEach((f, i) => this.tone(f, t + i * 0.075, 0.22, "triangle", 0.055));
        break;
      case "notify":
        this.tone(660, t, 0.1, "triangle", 0.045);
        this.tone(990, t + 0.08, 0.14, "triangle", 0.035);
        break;
      case "deny":
        this.tone(180, t, 0.16, "sawtooth", 0.05, 110);
        break;
      case "start":
        this.tone(120, t, 0.5, "sawtooth", 0.06, 420);
        this.tone(420, t + 0.08, 0.5, "sine", 0.05);
        break;
      case "complete":
        [392, 523, 659, 784, 1046].forEach((f, i) => this.tone(f, t + i * 0.11, 0.4, "sine", 0.06));
        break;
    }
  }
}

export const sound = new SoundEngine();

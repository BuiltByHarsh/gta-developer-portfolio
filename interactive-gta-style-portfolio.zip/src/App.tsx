import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { gsap } from "gsap";
import Background from "@/components/Background";
import CustomCursor from "@/components/CustomCursor";
import HUD from "@/components/HUD";
import LoadingScreen from "@/components/LoadingScreen";
import MiniMap from "@/components/MiniMap";
import TabNav from "@/components/TabNav";
import Toasts from "@/components/Toasts";
import { player, screens, ticker } from "@/config/portfolio";
import { useProgress } from "@/hooks/useProgress";
import { useToasts } from "@/hooks/useToasts";
import { sound } from "@/lib/audio";
import { formatStamp, prefersReducedMotion, useClock } from "@/lib/system";
import About from "@/screens/About";
import Achievements from "@/screens/Achievements";
import Contact from "@/screens/Contact";
import Experience from "@/screens/Experience";
import Home from "@/screens/Home";
import Outro from "@/screens/Outro";
import Projects from "@/screens/Projects";
import Services from "@/screens/Services";
import Skills from "@/screens/Skills";
import type { ScreenProps } from "@/screens/types";

const components = [Home, About, Skills, Projects, Experience, Achievements, Services, Contact, Outro];

const mix = (a: number, b: number, t: number) => Math.round(a + (b - a) * t);

/** Isolated clock so the ticking doesn't re-render the whole world. */
const SystemStamp = () => {
  const now = useClock();
  return (
    <span className="hidden font-mono text-[9px] tracking-[0.16em] text-bone-500 uppercase xl:inline">
      SYS {formatStamp(now)} · {player.version}
    </span>
  );
};

export default function App() {
  const [booted, setBooted] = useState(false);
  const [index, setIndex] = useState(0);
  const [shown, setShown] = useState(0);
  const [soundOn, setSoundOn] = useState(false);

  const progress = useProgress();
  const { toasts, push, dismiss } = useToasts();

  const busy = useRef(false);
  const indexRef = useRef(0);
  const announced = useRef<Set<string>>(new Set());
  const veilRef = useRef<HTMLDivElement>(null);
  const bootMsgRef = useRef<HTMLSpanElement>(null);

  const screen = screens[index];
  const Active = components[shown];

  /* ── restore saved audio preference (never autoplays: only armed) ── */
  useEffect(() => {
    if (progress.data.sound) setSoundOn(true);
    const arm = () => sound.setEnabled(soundOn);
    window.addEventListener("pointerdown", arm, { once: true });
    return () => window.removeEventListener("pointerdown", arm);
  }, [soundOn, progress.data.sound]);

  /* ── theme: animate the CSS accent variables between sectors ── */
  useEffect(() => {
    const root = document.documentElement;
    const target = screens[index];
    const cs = getComputedStyle(root);
    const fromA = gsap.utils.splitColor(cs.getPropertyValue("--accent").trim() || target.accent);
    const toA = gsap.utils.splitColor(target.accent);
    const fromB = gsap.utils.splitColor(cs.getPropertyValue("--accent-2").trim() || target.accent2);
    const toB = gsap.utils.splitColor(target.accent2);
    const proxy = { t: 0 };
    const tween = gsap.to(proxy, {
      t: 1,
      duration: prefersReducedMotion() ? 0 : 0.85,
      ease: "power2.inOut",
      onUpdate: () => {
        const a = [mix(fromA[0], toA[0], proxy.t), mix(fromA[1], toA[1], proxy.t), mix(fromA[2], toA[2], proxy.t)];
        const b = [mix(fromB[0], toB[0], proxy.t), mix(fromB[1], toB[1], proxy.t), mix(fromB[2], toB[2], proxy.t)];
        root.style.setProperty("--accent", `rgb(${a[0]}, ${a[1]}, ${a[2]})`);
        root.style.setProperty("--accent-rgb", `${a[0]}, ${a[1]}, ${a[2]}`);
        root.style.setProperty("--accent-2", `rgb(${b[0]}, ${b[1]}, ${b[2]})`);
      },
    });
    return () => {
      tween.kill();
    };
  }, [index]);

  /* ── navigation with a synchronised out/in transition ── */
  const go = useCallback(
    (next: number) => {
      const idx = ((next % screens.length) + screens.length) % screens.length;
      if (busy.current || idx === indexRef.current) return;
      busy.current = true;
      indexRef.current = idx;
      sound.play("switch");
      setIndex(idx);
      if (bootMsgRef.current) bootMsgRef.current.textContent = screens[idx].boot;

      const body = document.getElementById("screen-body");
      const bg = document.getElementById("bg-active");
      const veil = veilRef.current;

      if (prefersReducedMotion() || !body || !bg) {
        setShown(idx);
        busy.current = false;
        return;
      }

      gsap.killTweensOf([body, bg]);
      if (veil) gsap.killTweensOf(veil);
      const tl = gsap.timeline();
      tl.to(body, { opacity: 0, y: -14, duration: 0.2, ease: "power2.in" })
        .to(bg, { scale: 1.08, opacity: 0.25, duration: 0.26, ease: "power2.in" }, 0)
        .to(veil, { autoAlpha: 0.92, duration: 0.16, ease: "power1.in" }, 0.04)
        .add(() => setShown(idx))
        .to(veil, { autoAlpha: 0, duration: 0.5, ease: "power2.out" }, "+=0.06")
        .fromTo(bg, { scale: 1.1, opacity: 0 }, { scale: 1, opacity: 1, duration: 0.85, ease: "power2.out" }, "<")
        .to(body, { opacity: 1, y: 0, duration: 0.34, ease: "power2.out" }, "<0.04")
        .add(() => {
          busy.current = false;
        });
    },
    [],
  );

  const goById = useCallback((id: string) => go(screens.findIndex((s) => s.id === id)), [go]);

  /* ── progress + unlock toasts ── */
  useEffect(() => {
    const s = screens[index];
    const fresh = !progress.visited.has(s.id);
    progress.markVisited(s.id);
    if (fresh && !announced.current.has(s.id)) {
      announced.current.add(s.id);
      if (booted) {
        sound.play("unlock");
        push(s.unlock, `${s.sector} · +${s.xp} XP`, s.id === "outro" ? "complete" : "unlock");
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [index, booted]);

  /* ── keyboard navigation ── */
  useEffect(() => {
    if (!booted) return;
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
        e.preventDefault();
        go(indexRef.current + (e.key === "ArrowRight" ? 1 : -1));
        return;
      }
      if (/^[1-9]$/.test(e.key)) {
        e.preventDefault();
        go(Number(e.key) - 1);
        return;
      }
      if (e.key === "Escape") {
        e.preventDefault();
        go(0);
        return;
      }
      if ((e.key === "ArrowDown" || e.key === "ArrowUp") && tag !== "INPUT") {
        const items = Array.from(document.querySelectorAll<HTMLElement>("#screen-body [data-item]"));
        if (!items.length) return;
        e.preventDefault();
        const cur = items.indexOf(document.activeElement as HTMLElement);
        const nextIdx = cur === -1 ? 0 : (cur + (e.key === "ArrowDown" ? 1 : -1) + items.length) % items.length;
        items[nextIdx]?.focus();
        items[nextIdx]?.scrollIntoView({ block: "nearest" });
        sound.play("hover");
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [booted, go]);

  /* ── swipe navigation on touch ── */
  const touch = useRef<{ x: number; y: number } | null>(null);
  const onTouchStart = (e: React.TouchEvent) => {
    const t = e.touches[0];
    touch.current = { x: t.clientX, y: t.clientY };
  };
  const onTouchEnd = (e: React.TouchEvent) => {
    if (!touch.current) return;
    const t = e.changedTouches[0];
    const dx = t.clientX - touch.current.x;
    const dy = t.clientY - touch.current.y;
    if (Math.abs(dx) > 64 && Math.abs(dy) < 90) go(indexRef.current + (dx < 0 ? 1 : -1));
    touch.current = null;
  };

  /* ── intro once the boot sequence finishes ── */
  const onBootDone = () => {
    setBooted(true);
    const body = document.getElementById("screen-body");
    const bg = document.getElementById("bg-active");
    if (!prefersReducedMotion() && body && bg) {
      gsap.fromTo(bg, { scale: 1.14, opacity: 0 }, { scale: 1, opacity: 1, duration: 1.4, ease: "power2.out" });
      gsap.fromTo(body, { opacity: 0, y: 22 }, { opacity: 1, y: 0, duration: 0.7, ease: "power3.out", delay: 0.15 });
    }
    if (progress.saveFound) {
      window.setTimeout(
        () => push("SAVE DATA FOUND", `${progress.completion}% COMPLETE · SAVE SLOT 01`, "save", 4200),
        900,
      );
    } else {
      window.setTimeout(() => push("WORLD ENTRY ONLINE", "PRESS → TO TRAVEL · 1–9 TO JUMP", "info", 4600), 900);
    }
  };

  const toggleSound = () => {
    const next = !soundOn;
    setSoundOn(next);
    sound.setEnabled(next);
    progress.toggleSound(next);
    if (next) sound.play("select");
  };

  const screenProps = useMemo<ScreenProps>(
    () => ({ progress, toast: push, go: goById }),
    [progress, push, goById],
  );

  return (
    <div
      className="relative flex h-[100dvh] w-full flex-col overflow-hidden"
      onTouchStart={onTouchStart}
      onTouchEnd={onTouchEnd}
    >
      <Background screen={screen} />

      <HUD
        screen={screen}
        stars={progress.stars}
        xp={progress.xp}
        completion={progress.completion}
        soundOn={soundOn}
        onToggleSound={toggleSound}
      />

      <TabNav active={index} visited={progress.visited} onSelect={go} />

      <main className="relative z-20 flex min-h-0 flex-1 flex-col px-3 pt-3 pb-[36px] sm:px-6 sm:pt-4">
        <div id="screen-body" className="scroll-y flex min-h-0 flex-1 flex-col lg:overflow-hidden">
          <Active key={shown} {...screenProps} />
        </div>
      </main>

      <MiniMap screen={screen} visited={progress.visited} />
      <Toasts toasts={toasts} onDismiss={dismiss} />
      <CustomCursor />

      {/* transition veil */}
      <div
        ref={veilRef}
        className="pointer-events-none fixed inset-0 z-[90] flex items-center justify-center bg-ink-950 opacity-0"
        aria-hidden="true"
      >
        <div className="text-center">
          <div className="scanlines absolute inset-0" />
          <span ref={bootMsgRef} className="font-mono text-[11px] tracking-[0.28em] text-bone-300 uppercase">
            {screen.boot}
          </span>
        </div>
      </div>

      {/* bottom system bar */}
      <div className="fixed inset-x-0 bottom-0 z-30 flex h-[30px] items-center gap-3 border-t border-white/10 bg-black/75 px-3 backdrop-blur-[2px] sm:px-6">
        <span className="flex shrink-0 items-center gap-2">
          {/* compact minimap for touch layouts */}
          <span
            className="relative block h-[22px] w-[22px] shrink-0 border border-white/15 bg-black/70 sm:hidden"
            aria-hidden="true"
          >
            <svg viewBox="0 0 100 100" className="h-full w-full">
              <path d="M0,50 H100 M50,0 V100 M0,20 H100 M80,0 V100" stroke="rgba(255,255,255,0.16)" strokeWidth="5" />
              <circle cx={screen.map.x} cy={screen.map.y} r="11" fill="var(--accent)" />
            </svg>
          </span>
          <span className="h-1.5 w-1.5 anim-blink bg-[var(--accent)]" />
          <span className="font-mono text-[9px] tracking-[0.16em] text-bone-300 uppercase">
            <span className="sm:hidden">{screen.sector.replace("SECTOR ", "S")} · </span>
            {screen.gameLabel}
          </span>
        </span>
        <span className="hidden h-3 w-px bg-white/15 sm:block" />
        <span className="hidden overflow-hidden sm:block sm:flex-1">
          <span className="anim-ticker flex w-max gap-8">
            {[...ticker, ...ticker].map((t, i) => (
              <span key={i} className="font-mono text-[9px] tracking-[0.18em] whitespace-nowrap text-bone-500 uppercase">
                {t}
              </span>
            ))}
          </span>
        </span>
        <span className="ml-auto flex shrink-0 items-center gap-3">
          <SystemStamp />
          <span className="hidden font-mono text-[9px] tracking-[0.16em] text-bone-500 uppercase lg:inline">
            ← → SWITCH · 1–9 JUMP · ↑ ↓ SELECT · ESC HOME
          </span>
          <span
            className="font-mono text-[9px] tracking-[0.16em] uppercase"
            style={{ color: "var(--accent)" }}
          >
            {progress.completion}% COMPLETE
          </span>
        </span>
      </div>

      {!booted && <LoadingScreen onDone={onBootDone} saveFound={progress.saveFound} />}
    </div>
  );
}

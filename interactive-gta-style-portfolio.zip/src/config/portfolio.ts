/* ═══════════════════════════════════════════════════════════════════════════
   PORTFOLIO CONFIG — SINGLE SOURCE OF TRUTH
   Edit anything in this file. Every component reads from here.
   ▸ Links marked `pending: true` are placeholders — replace with real URLs.
   ═════════════════════════════════════════════════════════════════════════ */

import aboutImg from "@/assets/screens/about.jpg";
import achievementsImg from "@/assets/screens/achievements.jpg";
import contactImg from "@/assets/screens/contact.jpg";
import experienceImg from "@/assets/screens/experience.jpg";
import homeImg from "@/assets/screens/home.jpg";
import outroImg from "@/assets/screens/outro.jpg";
import projectsImg from "@/assets/screens/projects.jpg";
import servicesImg from "@/assets/screens/services.jpg";
import skillsImg from "@/assets/screens/skills.jpg";

export type ScreenId =
  | "home"
  | "about"
  | "skills"
  | "projects"
  | "experience"
  | "achievements"
  | "services"
  | "contact"
  | "outro";

export interface ScreenDef {
  id: ScreenId;
  num: string;
  /** plain label — used in tabs */
  label: string;
  /** in-world label — used in headers / toasts */
  gameLabel: string;
  sector: string;
  coords: string;
  accent: string;
  accent2: string;
  /** css fallback used if the artwork fails to load */
  fallback: string;
  image: string;
  /** optional looping background video — leave undefined to use the image */
  video?: string;
  /** background-position for the plate */
  position: string;
  /** minimap coordinates, 0–100 */
  map: { x: number; y: number };
  /** message shown in the transition loader */
  boot: string;
  /** toast fired the first time the sector is entered */
  unlock: string;
  /** XP awarded for discovering the sector */
  xp: number;
}

export const screens: ScreenDef[] = [
  {
    id: "home",
    num: "01",
    label: "HOME",
    gameLabel: "WORLD ENTRY",
    sector: "SECTOR 01",
    coords: "31.6861 N / 76.5231 E",
    accent: "#E85D04",
    accent2: "#FFB703",
    fallback: "linear-gradient(120deg,#120a04 0%,#2a1204 45%,#05070a 100%)",
    image: homeImg,
    position: "68% 40%",
    map: { x: 50, y: 52 },
    boot: "SPAWNING PLAYER...",
    unlock: "WORLD ENTRY ONLINE",
    xp: 1200,
  },
  {
    id: "about",
    num: "02",
    label: "ABOUT",
    gameLabel: "PLAYER PROFILE",
    sector: "SECTOR 02",
    coords: "31.6879 N / 76.5190 E",
    accent: "#3A86FF",
    accent2: "#48CAE4",
    fallback: "linear-gradient(120deg,#04080f 0%,#0b2545 50%,#05070a 100%)",
    image: aboutImg,
    position: "30% 35%",
    map: { x: 32, y: 38 },
    boot: "LOADING PLAYER PROFILE...",
    unlock: "PROFILE UNLOCKED",
    xp: 1600,
  },
  {
    id: "skills",
    num: "03",
    label: "SKILLS",
    gameLabel: "SKILL TREE",
    sector: "SECTOR 03",
    coords: "31.6842 N / 76.5288 E",
    accent: "#39E75F",
    accent2: "#00F5A0",
    fallback: "linear-gradient(120deg,#040b07 0%,#06301c 50%,#05070a 100%)",
    image: skillsImg,
    position: "55% 55%",
    map: { x: 66, y: 30 },
    boot: "SYNCING SKILL TREE...",
    unlock: "NEW SKILL DISCOVERED",
    xp: 2200,
  },
  {
    id: "projects",
    num: "04",
    label: "PROJECTS",
    gameLabel: "MISSION DATABASE",
    sector: "SECTOR 04",
    coords: "31.6801 N / 76.5344 E",
    accent: "#A855F7",
    accent2: "#F15BB5",
    fallback: "linear-gradient(120deg,#0b0512 0%,#2a0b45 50%,#05070a 100%)",
    image: projectsImg,
    position: "72% 45%",
    map: { x: 74, y: 62 },
    boot: "MISSION DATABASE LOADING...",
    unlock: "NEW MISSION DISCOVERED",
    xp: 2800,
  },
  {
    id: "experience",
    num: "05",
    label: "EXPERIENCE",
    gameLabel: "MISSION HISTORY",
    sector: "SECTOR 05",
    coords: "31.6888 N / 76.5122 E",
    accent: "#FF3B3B",
    accent2: "#FF7B54",
    fallback: "linear-gradient(120deg,#0f0505 0%,#3d0b0b 50%,#05070a 100%)",
    image: experienceImg,
    position: "35% 50%",
    map: { x: 44, y: 74 },
    boot: "READING MISSION HISTORY...",
    unlock: "MISSION LOG DECRYPTED",
    xp: 2400,
  },
  {
    id: "achievements",
    num: "06",
    label: "ACHIEVEMENTS",
    gameLabel: "TROPHY ROOM",
    sector: "SECTOR 06",
    coords: "31.6912 N / 76.5266 E",
    accent: "#FFC300",
    accent2: "#FFD166",
    fallback: "linear-gradient(120deg,#0d0903 0%,#3d2a05 50%,#05070a 100%)",
    image: achievementsImg,
    position: "50% 30%",
    map: { x: 22, y: 66 },
    boot: "INDEXING TROPHIES...",
    unlock: "TROPHY ROOM OPEN",
    xp: 2000,
  },
  {
    id: "services",
    num: "07",
    label: "SERVICES",
    gameLabel: "AVAILABLE CONTRACTS",
    sector: "SECTOR 07",
    coords: "31.6820 N / 76.5175 E",
    accent: "#00C2CB",
    accent2: "#5EEAD4",
    fallback: "linear-gradient(120deg,#030c0e 0%,#063b41 50%,#05070a 100%)",
    image: servicesImg,
    position: "60% 50%",
    map: { x: 58, y: 82 },
    boot: "SCANNING CONTRACT BOARD...",
    unlock: "CONTRACT BOARD AVAILABLE",
    xp: 1800,
  },
  {
    id: "contact",
    num: "08",
    label: "CONTACT",
    gameLabel: "CONTACT HQ",
    sector: "SECTOR 08",
    coords: "31.6855 N / 76.5301 E",
    accent: "#FF4D9D",
    accent2: "#FF8FAB",
    fallback: "linear-gradient(120deg,#10050b 0%,#3d0b26 50%,#05070a 100%)",
    image: contactImg,
    position: "45% 60%",
    map: { x: 82, y: 44 },
    boot: "ESTABLISHING CONNECTION...",
    unlock: "CONTACT HQ AVAILABLE",
    xp: 2600,
  },
  {
    id: "outro",
    num: "09",
    label: "EXIT",
    gameLabel: "MISSION COMPLETE",
    sector: "SECTOR 09",
    coords: "31.6899 N / 76.5410 E",
    accent: "#FF9E00",
    accent2: "#FFE8A3",
    fallback: "linear-gradient(120deg,#100a02 0%,#4a2b02 45%,#05070a 100%)",
    image: outroImg,
    position: "50% 45%",
    map: { x: 40, y: 18 },
    boot: "CLOSING SESSION...",
    unlock: "MISSION PASSED",
    xp: 4000,
  },
];

export const byId = (id: ScreenId) => screens.find((s) => s.id === id)!;

/* ─────────────────────────── PLAYER ─────────────────────────── */

export const player = {
  name: "HARSH SHARMA",
  first: "HARSH",
  last: "SHARMA",
  handle: "HS",
  playerId: "HS-001",
  title: "CREATIVE DEVELOPER",
  class: "FRONT-END · MOTION · INTERFACE",
  tagline: "BUILDING DIGITAL EXPERIENCES THAT FEEL ALIVE.",
  location: "HAMIRPUR, HIMACHAL PRADESH",
  region: "IN — HP",
  coords: "31.6861° N / 76.5231° E",
  build: "BUILD 2026.08",
  version: "v1.0.0 · STATIC",
  level: 12,
  status: "AVAILABLE FOR WORK",
  timezone: "IST (UTC+5:30)",
  bio: [
    "Front-end focused developer working out of Hamirpur, Himachal Pradesh. I build fast, cinematic web experiences — interface systems, motion, and the small details that make a product feel alive rather than merely functional.",
    "My work sits between design and engineering: layout systems, responsive behaviour, scroll-driven motion and performance budgets. I care about how a page loads, how it responds to a thumb on a small screen, and how it feels one minute after you arrive.",
    "Currently deep in the React + Astro stack, sharpening TypeScript, and taking on select freelance contracts.",
  ],
  direction:
    "Moving toward product engineering — design systems, motion tooling and interfaces that stay fast under real content.",
  interests: [
    "Interface motion",
    "Open-world game UI",
    "Street photography",
    "Type & grid systems",
    "Himalayan treks",
    "Lo-fi while coding",
  ],
  strengths: [
    "Turns loose ideas into shipped screens",
    "Obsessive about spacing, rhythm and hierarchy",
    "Debugs patiently, explains clearly",
    "Ships small and often instead of big and late",
  ],
};

export const education = [
  {
    id: "EDU-01",
    degree: "UNDERGRADUATE PROGRAMME",
    field: "COMPUTER SCIENCE",
    institution: "INSTITUTION RECORD — PENDING UPLOAD",
    period: "IN PROGRESS",
    status: "RECORD INCOMPLETE",
    note: "Coursework focus: data structures, web systems, databases. Full record added once verified.",
  },
  {
    id: "EDU-02",
    degree: "SELF-DIRECTED TRAINING",
    field: "FRONT-END ENGINEERING & UI DESIGN",
    institution: "OPEN WEB · DOCUMENTATION · BUILD LOGS",
    period: "2023 — ONGOING",
    status: "ACTIVE",
    note: "MDN, framework docs, source-reading, and shipping small projects every month.",
  },
];

/* ─────────────────────────── STATS ─────────────────────────── */

export const stats = [
  { label: "CREATIVITY", value: 90, note: "Concept + visual direction" },
  { label: "TECHNICAL", value: 80, note: "Front-end engineering" },
  { label: "DESIGN", value: 86, note: "Layout, type, systems" },
  { label: "PROBLEM SOLVING", value: 84, note: "Debugging + architecture" },
  { label: "COMMUNICATION", value: 78, note: "Docs, updates, handoff" },
];

export const attributes = [
  { label: "ACCURACY", value: 88 },
  { label: "STAMINA", value: 82 },
  { label: "STEALTH", value: 64 },
  { label: "DRIVING", value: 71 },
];

/* ─────────────────────────── SKILL TREE ─────────────────────────── */

export interface Skill {
  name: string;
  level: number; // 1–10 (qualitative, not a percentage claim)
  icon: string;
  note: string;
}
export interface SkillBranch {
  id: string;
  name: string;
  tagline: string;
  skills: Skill[];
}

export const skillBranches: SkillBranch[] = [
  {
    id: "dev",
    name: "DEVELOPMENT",
    tagline: "Core engineering branch — markup to shipped build",
    skills: [
      { name: "HTML5", level: 9, icon: "file-code", note: "Semantic structure, forms, a11y attributes" },
      { name: "CSS3 / TAILWIND", level: 9, icon: "palette", note: "Grid, flex, custom properties, utility systems" },
      { name: "JAVASCRIPT (ES6+)", level: 8, icon: "braces", note: "Async, DOM APIs, module patterns" },
      { name: "REACT", level: 7, icon: "layers", note: "Hooks, composition, state flow" },
      { name: "ASTRO", level: 7, icon: "rocket", note: "Islands, zero-JS pages, content collections" },
      { name: "GSAP / MOTION", level: 7, icon: "zap", note: "Timelines, ScrollTrigger, transitions" },
      { name: "TYPESCRIPT", level: 6, icon: "terminal", note: "Typed props, config-driven data" },
      { name: "GIT / GITHUB", level: 7, icon: "git-branch", note: "Branching, clean commits, deploy hooks" },
    ],
  },
  {
    id: "design",
    name: "DESIGN",
    tagline: "Interface craft — from wireframe to final frame",
    skills: [
      { name: "UI DESIGN", level: 8, icon: "pen-tool", note: "Hierarchy, contrast, component thinking" },
      { name: "RESPONSIVE DESIGN", level: 9, icon: "smartphone", note: "Mobile-first, fluid type, touch targets" },
      { name: "MOTION DESIGN", level: 7, icon: "activity", note: "Easing, choreography, feedback states" },
      { name: "DESIGN SYSTEMS", level: 6, icon: "layout", note: "Tokens, spacing scales, reusable parts" },
      { name: "UX FLOW", level: 7, icon: "compass", note: "Navigation, states, empty + error paths" },
    ],
  },
  {
    id: "other",
    name: "SUPPORT / OPS",
    tagline: "Everything that keeps the build alive",
    skills: [
      { name: "PERFORMANCE", level: 6, icon: "gauge", note: "Lazy loading, asset budgets, profiling" },
      { name: "ACCESSIBILITY", level: 6, icon: "accessibility", note: "Keyboard paths, focus, reduced motion" },
      { name: "DEPLOYMENT", level: 6, icon: "upload", note: "Static hosting, builds, previews" },
      { name: "PROBLEM SOLVING", level: 8, icon: "crosshair", note: "Isolating bugs, reading stack traces" },
    ],
  },
];

/* ─────────────────────────── MISSIONS / PROJECTS ─────────────────────────── */

export interface Mission {
  id: string;
  code: string;
  title: string;
  type: string;
  status: "COMPLETED" | "IN PROGRESS" | "PLANNED";
  year: string;
  role: string;
  difficulty: string;
  xp: number;
  objective: string;
  brief: string;
  deliverables: string[];
  tech: string[];
  repo: string | null;
  live: string | null;
}

export const missions: Mission[] = [
  {
    id: "m1",
    code: "MISSION 001",
    title: "CREATIVE PORTFOLIO",
    type: "WEB DEVELOPMENT",
    status: "COMPLETED",
    year: "2026",
    role: "DESIGN + DEVELOPMENT",
    difficulty: "HARD",
    xp: 3200,
    objective: "Turn a portfolio into a world you can walk through.",
    brief:
      "A game-interface portfolio: persistent HUD, live clock, minimap, star progression, save data in localStorage and nine fully art-directed sectors — all driven from one config file.",
    deliverables: [
      "Nine-screen sector system with per-sector theming",
      "Persistent HUD: clock, reputation, XP counter",
      "Keyboard + touch navigation across every screen",
      "Progress saved locally, restored on return visits",
    ],
    tech: ["React", "TypeScript", "GSAP", "Tailwind CSS"],
    repo: null,
    live: null,
  },
  {
    id: "m2",
    code: "MISSION 002",
    title: "ASTRO STATIC SITE",
    type: "WEB DEVELOPMENT",
    status: "COMPLETED",
    year: "2025",
    role: "DEVELOPMENT",
    difficulty: "MEDIUM",
    xp: 2100,
    objective: "Ship a content site that loads instantly on slow connections.",
    brief:
      "Island-architecture build with content collections, zero blocking scripts and an aggressive asset budget. Typed frontmatter, generated routes, static output.",
    deliverables: [
      "Content collections + typed frontmatter",
      "Island components only where interactivity is needed",
      "Image pipeline with responsive sources",
      "Static deploy to CDN hosting",
    ],
    tech: ["Astro", "TypeScript", "CSS"],
    repo: null,
    live: null,
  },
  {
    id: "m3",
    code: "MISSION 003",
    title: "MOTION LANDING PAGE",
    type: "WEB DEVELOPMENT",
    status: "COMPLETED",
    year: "2025",
    role: "DESIGN + MOTION",
    difficulty: "MEDIUM",
    xp: 1900,
    objective: "Tell a product story through scroll, not through copy length.",
    brief:
      "Scroll-driven landing page with pinned panels, staggered reveals and a reduced-motion path that keeps the whole narrative readable without animation.",
    deliverables: [
      "ScrollTrigger pinned sequences",
      "Staggered reveal system reused across sections",
      "Reduced-motion fallback layout",
      "60fps target on mid-range mobile",
    ],
    tech: ["HTML", "CSS", "JavaScript", "GSAP"],
    repo: null,
    live: null,
  },
  {
    id: "m4",
    code: "MISSION 004",
    title: "UI COMPONENT LAB",
    type: "DESIGN SYSTEM",
    status: "COMPLETED",
    year: "2025",
    role: "DESIGN + DEVELOPMENT",
    difficulty: "MEDIUM",
    xp: 1700,
    objective: "Stop rebuilding the same button. Build the library instead.",
    brief:
      "A typed component set with design tokens: colour, spacing, type scale, elevation. Every variant documented next to the code that renders it.",
    deliverables: [
      "Token layer (colour, space, type, radius)",
      "Accessible primitives with visible focus states",
      "Dark + light themes from one token set",
      "Usage docs alongside each component",
    ],
    tech: ["React", "TypeScript", "Tailwind CSS"],
    repo: null,
    live: null,
  },
  {
    id: "m5",
    code: "MISSION 005",
    title: "CANVAS MINI GAME",
    type: "EXPERIMENT",
    status: "COMPLETED",
    year: "2024",
    role: "DEVELOPMENT",
    difficulty: "EASY",
    xp: 1200,
    objective: "Learn the game loop from the inside.",
    brief:
      "A browser mini-game prototype built on the Canvas API — requestAnimationFrame loop, collision checks, score state and a pause system. Where the game-UI obsession started.",
    deliverables: [
      "Fixed-timestep game loop",
      "Sprite + collision handling on canvas",
      "Pause / resume with visibility API",
      "Local high-score persistence",
    ],
    tech: ["JavaScript", "Canvas API", "HTML"],
    repo: null,
    live: null,
  },
  {
    id: "m6",
    code: "MISSION 006",
    title: "OPEN SOURCE TRACK",
    type: "CONTRIBUTION",
    status: "IN PROGRESS",
    year: "2026",
    role: "CONTRIBUTOR",
    difficulty: "ONGOING",
    xp: 800,
    objective: "Ship useful patches to projects other people depend on.",
    brief:
      "Reading source, filing precise issues, sending small fixes — docs, types, edge-case bugs. Currently in progress; the first merged PR unlocks the achievement.",
    deliverables: [
      "Source-reading and issue triage",
      "Small, reviewable pull requests",
      "Documentation and type fixes",
    ],
    tech: ["Git", "GitHub", "TypeScript"],
    repo: null,
    live: null,
  },
];

/** GitHub presence — set `profile` to a real handle to activate the links. */
export const github = {
  profile: "https://github.com/",
  handle: "PROFILE LINK PENDING",
  pending: true,
  note: "Repositories listed below are the mission records above. Connect the real handle in src/config/portfolio.ts to activate direct links.",
};

/* ─────────────────────────── EXPERIENCE ─────────────────────────── */

export interface ExperienceEntry {
  id: string;
  year: string;
  role: string;
  org: string;
  type: string;
  status: string;
  summary: string;
  duties: string[];
  tech: string[];
  wins: string[];
}

export const experience: ExperienceEntry[] = [
  {
    id: "xp1",
    year: "2026",
    role: "WEB DESIGN & DEVELOPMENT",
    org: "FREELANCE — REMOTE",
    type: "CONTRACT WORK",
    status: "CURRENT",
    summary:
      "Independent front-end work: interface design, build and handoff for portfolio sites, landing pages and small business websites.",
    duties: [
      "Scope the build with the client, then design and build the front end",
      "Translate layouts into responsive, accessible markup",
      "Handle motion, performance passes and deployment",
    ],
    tech: ["HTML", "CSS", "JavaScript", "React", "Astro"],
    wins: ["Shipped builds that stay fast on low-end devices", "Config-driven setups clients can edit themselves"],
  },
  {
    id: "xp2",
    year: "2025",
    role: "INDEPENDENT PROJECT PHASE",
    org: "SELF-INITIATED BUILDS",
    type: "PRACTICE",
    status: "COMPLETED",
    summary:
      "A year of deliberate practice: one project at a time, each one targeting a specific gap — motion, static generation, component systems.",
    duties: [
      "Scoped, designed and shipped personal projects end to end",
      "Rebuilt interfaces from reference designs to study craft",
      "Kept a build log of what worked and what didn't",
    ],
    tech: ["JavaScript", "React", "Astro", "GSAP", "Git"],
    wins: ["Six shipped projects", "Comfortable shipping without a template"],
  },
  {
    id: "xp3",
    year: "2024",
    role: "FOUNDATIONS",
    org: "SELF-TAUGHT",
    type: "TRAINING",
    status: "COMPLETED",
    summary:
      "Where it started — markup, layout and the first websites that actually went live. Long nights, broken layouts, small wins.",
    duties: [
      "Learned semantic HTML, CSS layout and vanilla JavaScript",
      "Built and deployed the first websites",
      "Started version-controlling everything",
    ],
    tech: ["HTML", "CSS", "JavaScript", "Git"],
    wins: ["First website live", "Version control habit formed"],
  },
];

/* ─────────────────────────── ACHIEVEMENTS ─────────────────────────── */

export interface Achievement {
  id: string;
  name: string;
  desc: string;
  icon: string;
  unlocked: boolean;
  xp: number;
  date?: string;
}

export const achievements: Achievement[] = [
  { id: "a1", name: "FIRST WEBSITE", desc: "Put a site on the internet. It loaded. It worked.", icon: "globe", unlocked: true, xp: 250, date: "2024" },
  { id: "a2", name: "PROJECT BUILDER", desc: "Shipped five or more complete builds.", icon: "hammer", unlocked: true, xp: 500, date: "2025" },
  { id: "a3", name: "DESIGN EXPLORER", desc: "Designed interfaces from a blank canvas, not a template.", icon: "pen-tool", unlocked: true, xp: 400, date: "2025" },
  { id: "a4", name: "CODE BREAKER", desc: "Debugged a bug that survived three days.", icon: "crosshair", unlocked: true, xp: 450, date: "2025" },
  { id: "a5", name: "MOTION CRAFT", desc: "Built a scroll-driven experience at 60fps.", icon: "zap", unlocked: true, xp: 500, date: "2025" },
  { id: "a6", name: "CLEAN COMMIT", desc: "A month of small, readable commits.", icon: "git-branch", unlocked: true, xp: 300, date: "2025" },
  { id: "a7", name: "NIGHT SHIFT", desc: "Shipped something at 3 AM and it worked.", icon: "moon", unlocked: true, xp: 200, date: "2024" },
  { id: "a8", name: "FULL STACK JOURNEY", desc: "???", icon: "lock", unlocked: false, xp: 900 },
  { id: "a9", name: "OPEN SOURCE CONTRIBUTOR", desc: "???", icon: "lock", unlocked: false, xp: 750 },
  { id: "a10", name: "FIRST CLIENT CONTRACT", desc: "???", icon: "lock", unlocked: false, xp: 800 },
  { id: "a11", name: "TEAM OPERATIVE", desc: "???", icon: "lock", unlocked: false, xp: 650 },
];

/* ─────────────────────────── CONTRACTS / SERVICES ─────────────────────────── */

export interface Contract {
  id: string;
  code: string;
  title: string;
  scope: string;
  status: "AVAILABLE" | "LIMITED";
  summary: string;
  includes: string[];
  turnaround: string;
  icon: string;
}

export const contracts: Contract[] = [
  {
    id: "c1",
    code: "CONTRACT #001",
    title: "WEB DEVELOPMENT",
    scope: "BUILD · SHIP",
    status: "AVAILABLE",
    summary: "Custom front-end builds — no page builders, no template debt. Clean code you own.",
    includes: ["Component architecture", "Responsive implementation", "Performance pass", "Deploy + handoff"],
    turnaround: "2 — 4 WEEKS",
    icon: "code",
  },
  {
    id: "c2",
    code: "CONTRACT #002",
    title: "UI / UX DESIGN",
    scope: "DESIGN · SYSTEM",
    status: "AVAILABLE",
    summary: "Interface design grounded in grids and type, delivered as a system rather than loose screens.",
    includes: ["Wireframes + flows", "Visual direction", "Component set", "Responsive specs"],
    turnaround: "1 — 3 WEEKS",
    icon: "pen-tool",
  },
  {
    id: "c3",
    code: "CONTRACT #003",
    title: "PORTFOLIO WEBSITES",
    scope: "PERSONAL BRAND",
    status: "AVAILABLE",
    summary: "A portfolio with a point of view — the thing you send instead of a PDF.",
    includes: ["Narrative structure", "Project case pages", "Contact pipeline", "Domain + deploy"],
    turnaround: "1 — 2 WEEKS",
    icon: "user",
  },
  {
    id: "c4",
    code: "CONTRACT #004",
    title: "BUSINESS WEBSITES",
    scope: "COMMERCIAL",
    status: "LIMITED",
    summary: "Fast, credible sites for local businesses — built to load anywhere, edited by you.",
    includes: ["Content structure", "SEO fundamentals", "Enquiry handling", "Editable content"],
    turnaround: "2 — 3 WEEKS",
    icon: "briefcase",
  },
  {
    id: "c5",
    code: "CONTRACT #005",
    title: "LANDING PAGES",
    scope: "CONVERSION",
    status: "AVAILABLE",
    summary: "One page, one message, one action. Motion used to direct attention, not to decorate.",
    includes: ["Copy structure", "Motion design", "A/B variants", "Analytics hooks"],
    turnaround: "5 — 10 DAYS",
    icon: "target",
  },
  {
    id: "c6",
    code: "CONTRACT #006",
    title: "WEBSITE REDESIGN",
    scope: "REBUILD",
    status: "AVAILABLE",
    summary: "Rescue an existing site: faster load, cleaner hierarchy, layouts that survive real content.",
    includes: ["Audit + fixes", "New layout system", "Accessibility pass", "Migration"],
    turnaround: "1 — 3 WEEKS",
    icon: "wrench",
  },
];

/* ─────────────────────────── CONTACT ─────────────────────────── */

export const contact = {
  email: "harsh.sharma@example.com", // ← replace with the real address
  phone: null as string | null, // ← e.g. "+91 00000 00000" — null renders as "ON REQUEST"
  location: "HAMIRPUR, HIMACHAL PRADESH, INDIA",
  availability: "OPEN TO FREELANCE · REMOTE",
  responseTime: "USUALLY WITHIN 24 HOURS",
  socials: [
    { label: "GITHUB", value: "PROFILE PENDING", url: "https://github.com/", icon: "github", pending: true },
    { label: "LINKEDIN", value: "PROFILE PENDING", url: "https://www.linkedin.com/", icon: "linkedin", pending: true },
    { label: "INSTAGRAM", value: "PROFILE PENDING", url: "https://www.instagram.com/", icon: "instagram", pending: true },
  ],
};

/* ─────────────────────────── SYSTEM STRINGS ─────────────────────────── */

export const bootMessages = [
  "INITIALIZING PLAYER PROFILE",
  "LOADING PROJECTS",
  "SYNCING SKILLS",
  "LOADING EXPERIENCE",
  "ESTABLISHING CONNECTION",
  "SYSTEM READY",
];

export const ticker = [
  "SYSTEM // ONLINE",
  "PLAYER // HS",
  `REGION // ${player.region}`,
  "SAVE SLOT // 01",
  "STATIC BUILD // NO BACKEND",
  "KEYBOARD // ← → SWITCH · 1–9 JUMP · ESC BACK",
  "PROGRESS // SAVED LOCALLY",
  "AUDIO // OPTIONAL",
];
